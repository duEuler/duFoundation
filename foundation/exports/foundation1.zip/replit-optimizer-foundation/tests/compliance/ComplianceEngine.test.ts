// tests/compliance/ComplianceEngine.test.ts
import { describe, it, expect, beforeEach, vi } from 'vitest';

// Mock ComplianceEngine class for testing
class ComplianceEngine {
  private policies: Map<string, any> = new Map();
  private auditLog: any[] = [];

  constructor() {
    this.loadStandardPolicies();
  }

  private loadStandardPolicies() {
    this.policies.set('sox', {
      id: 'sox',
      name: 'Sarbanes-Oxley Compliance',
      category: 'financial',
      enforcement: 'strict',
      riskLevel: 'high'
    });
    
    this.policies.set('gdpr', {
      id: 'gdpr',
      name: 'GDPR Data Protection',
      category: 'privacy',
      enforcement: 'strict',
      riskLevel: 'critical'
    });
  }

  async validateCompliance(operation: any) {
    const violations: any[] = [];
    const warnings: any[] = [];
    
    if (operation.estimatedCost > 100 && !operation.hasApproval) {
      violations.push({
        policyId: 'sox',
        rule: 'financial_approval_required',
        severity: 'high',
        message: 'Operations with financial impact >$100 require formal approval'
      });
    }
    
    if (operation.data && this.containsPersonalData(operation.data) && !operation.hasLegalBasis) {
      violations.push({
        policyId: 'gdpr',
        rule: 'legal_basis_required',
        severity: 'critical',
        message: 'Processing personal data requires valid legal basis'
      });
    }

    return {
      isCompliant: violations.length === 0,
      violations,
      warnings,
      overallRisk: violations.some(v => v.severity === 'critical') ? 'critical' : 'medium',
      auditId: 'audit-' + Date.now()
    };
  }

  private containsPersonalData(data: any): boolean {
    if (!data) return false;
    const personalDataFields = ['email', 'name', 'phone', 'address'];
    return personalDataFields.some(field => data.hasOwnProperty(field));
  }

  async generateComplianceReport(period: string) {
    return {
      id: 'report-' + Date.now(),
      period,
      generatedAt: new Date(),
      scope: {
        totalOperations: this.auditLog.length,
        compliantOperations: this.auditLog.filter(a => a.compliance_status === 'compliant').length,
        nonCompliantOperations: this.auditLog.filter(a => a.compliance_status === 'non_compliant').length
      },
      riskLevel: 'medium',
      recommendations: [
        'Implement automated approval workflow for high-cost operations',
        'Add data encryption for personal information'
      ]
    };
  }

  async performComplianceAudit() {
    return {
      auditId: 'full-audit-' + Date.now(),
      timestamp: new Date(),
      auditor: 'system',
      scope: 'full_system',
      findings: [],
      overallRating: 'satisfactory',
      recommendations: [],
      actionPlan: []
    };
  }
}

describe('ComplianceEngine', () => {
  let complianceEngine: ComplianceEngine;
  
  beforeEach(() => {
    complianceEngine = new ComplianceEngine();
  });
  
  describe('policy loading', () => {
    it('should load standard compliance policies', () => {
      const policies = (complianceEngine as any).policies;
      
      expect(policies.has('sox')).toBe(true);
      expect(policies.has('gdpr')).toBe(true);
      
      const soxPolicy = policies.get('sox');
      expect(soxPolicy.name).toBe('Sarbanes-Oxley Compliance');
      expect(soxPolicy.category).toBe('financial');
      expect(soxPolicy.enforcement).toBe('strict');
    });
  });
  
  describe('validateCompliance', () => {
    it('should pass compliance for low-cost operations without personal data', async () => {
      const operation = {
        id: 'op-1',
        estimatedCost: 50,
        hasApproval: false,
        data: { projectName: 'test' }
      };
      
      const result = await complianceEngine.validateCompliance(operation);
      
      expect(result.isCompliant).toBe(true);
      expect(result.violations).toHaveLength(0);
      expect(result.warnings).toHaveLength(0);
    });
    
    it('should fail SOX compliance for high-cost operations without approval', async () => {
      const operation = {
        id: 'op-2',
        estimatedCost: 150,
        hasApproval: false,
        data: { projectName: 'expensive-operation' }
      };
      
      const result = await complianceEngine.validateCompliance(operation);
      
      expect(result.isCompliant).toBe(false);
      expect(result.violations).toHaveLength(1);
      expect(result.violations[0].policyId).toBe('sox');
      expect(result.violations[0].rule).toBe('financial_approval_required');
      expect(result.violations[0].severity).toBe('high');
    });
    
    it('should fail GDPR compliance for personal data processing without legal basis', async () => {
      const operation = {
        id: 'op-3',
        estimatedCost: 25,
        hasApproval: true,
        hasLegalBasis: false,
        data: {
          email: 'user@example.com',
          name: 'John Doe',
          projectName: 'user-data-analysis'
        }
      };
      
      const result = await complianceEngine.validateCompliance(operation);
      
      expect(result.isCompliant).toBe(false);
      expect(result.violations).toHaveLength(1);
      expect(result.violations[0].policyId).toBe('gdpr');
      expect(result.violations[0].rule).toBe('legal_basis_required');
      expect(result.violations[0].severity).toBe('critical');
      expect(result.overallRisk).toBe('critical');
    });
    
    it('should pass compliance for personal data processing with legal basis', async () => {
      const operation = {
        id: 'op-4',
        estimatedCost: 25,
        hasApproval: true,
        hasLegalBasis: true,
        data: {
          email: 'user@example.com',
          name: 'John Doe',
          projectName: 'user-data-analysis'
        }
      };
      
      const result = await complianceEngine.validateCompliance(operation);
      
      expect(result.isCompliant).toBe(true);
      expect(result.violations).toHaveLength(0);
    });
    
    it('should handle multiple policy violations', async () => {
      const operation = {
        id: 'op-5',
        estimatedCost: 200,
        hasApproval: false,
        hasLegalBasis: false,
        data: {
          email: 'user@example.com',
          name: 'John Doe'
        }
      };
      
      const result = await complianceEngine.validateCompliance(operation);
      
      expect(result.isCompliant).toBe(false);
      expect(result.violations).toHaveLength(2);
      expect(result.violations.some(v => v.policyId === 'sox')).toBe(true);
      expect(result.violations.some(v => v.policyId === 'gdpr')).toBe(true);
      expect(result.overallRisk).toBe('critical');
    });
  });
  
  describe('generateComplianceReport', () => {
    it('should generate compliance report with required fields', async () => {
      const report = await complianceEngine.generateComplianceReport('monthly');
      
      expect(report).toHaveProperty('id');
      expect(report).toHaveProperty('period');
      expect(report).toHaveProperty('generatedAt');
      expect(report).toHaveProperty('scope');
      expect(report).toHaveProperty('riskLevel');
      expect(report).toHaveProperty('recommendations');
      
      expect(report.period).toBe('monthly');
      expect(report.generatedAt).toBeInstanceOf(Date);
      expect(Array.isArray(report.recommendations)).toBe(true);
    });
    
    it('should include operation statistics', async () => {
      const report = await complianceEngine.generateComplianceReport('weekly');
      
      expect(report.scope).toHaveProperty('totalOperations');
      expect(report.scope).toHaveProperty('compliantOperations');
      expect(report.scope).toHaveProperty('nonCompliantOperations');
      
      expect(typeof report.scope.totalOperations).toBe('number');
      expect(typeof report.scope.compliantOperations).toBe('number');
      expect(typeof report.scope.nonCompliantOperations).toBe('number');
    });
    
    it('should provide actionable recommendations', async () => {
      const report = await complianceEngine.generateComplianceReport('daily');
      
      expect(report.recommendations.length).toBeGreaterThan(0);
      expect(report.recommendations[0]).toContain('approval workflow');
      expect(report.recommendations[1]).toContain('data encryption');
    });
  });
  
  describe('performComplianceAudit', () => {
    it('should perform full system compliance audit', async () => {
      const auditResult = await complianceEngine.performComplianceAudit();
      
      expect(auditResult).toHaveProperty('auditId');
      expect(auditResult).toHaveProperty('timestamp');
      expect(auditResult).toHaveProperty('auditor');
      expect(auditResult).toHaveProperty('scope');
      expect(auditResult).toHaveProperty('findings');
      expect(auditResult).toHaveProperty('overallRating');
      expect(auditResult).toHaveProperty('recommendations');
      expect(auditResult).toHaveProperty('actionPlan');
      
      expect(auditResult.auditor).toBe('system');
      expect(auditResult.scope).toBe('full_system');
      expect(auditResult.timestamp).toBeInstanceOf(Date);
      expect(Array.isArray(auditResult.findings)).toBe(true);
      expect(Array.isArray(auditResult.recommendations)).toBe(true);
      expect(Array.isArray(auditResult.actionPlan)).toBe(true);
    });
  });
});