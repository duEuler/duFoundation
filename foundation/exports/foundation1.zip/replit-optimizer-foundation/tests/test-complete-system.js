#!/usr/bin/env node

/**
 * Script de Teste Completo do Sistema
 * Testa todas as funcionalidades principais da plataforma
 */

const API_BASE = 'http://localhost:5000';

// Cores para output no terminal
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  dim: '\x1b[2m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  white: '\x1b[37m'
};

// Função para fazer requisições HTTP
async function makeRequest(method, url, data = null, headers = {}) {
  const defaultHeaders = {
    'Content-Type': 'application/json',
    ...headers
  };

  const config = {
    method,
    headers: defaultHeaders
  };

  if (data && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
    config.body = JSON.stringify(data);
  }

  try {
    const response = await fetch(`${API_BASE}${url}`, config);
    const responseData = await response.text();
    
    let parsedData;
    try {
      parsedData = JSON.parse(responseData);
    } catch {
      parsedData = responseData;
    }

    return {
      status: response.status,
      ok: response.ok,
      data: parsedData,
      headers: response.headers
    };
  } catch (error) {
    return {
      status: 0,
      ok: false,
      error: error.message,
      data: null
    };
  }
}

// Função para log com cores
function log(message, color = 'white', prefix = '') {
  console.log(`${colors[color]}${prefix}${message}${colors.reset}`);
}

function logSuccess(message) {
  log(`✓ ${message}`, 'green');
}

function logError(message) {
  log(`✗ ${message}`, 'red');
}

function logWarning(message) {
  log(`⚠ ${message}`, 'yellow');
}

function logInfo(message) {
  log(`ℹ ${message}`, 'blue');
}

function logSection(title) {
  log(`\n${'='.repeat(60)}`, 'cyan');
  log(`${title}`, 'cyan', '  ');
  log(`${'='.repeat(60)}`, 'cyan');
}

// Dados de teste
const testData = {
  user: {
    email: 'teste@marketplace.com',
    password: 'senha123',
    name: 'Usuário Teste',
    userType: 'customer'
  },
  admin: {
    username: 'admin',
    password: 'admin123'
  },
  product: {
    title: 'Template Teste',
    description: 'Template para testes automatizados',
    price: '29.90',
    category: 'Templates',
    isPremium: true
  }
};

let authToken = null;
let testUserId = null;
let resetToken = null;

// Testes de Autenticação
async function testAuthentication() {
  logSection('TESTES DE AUTENTICAÇÃO');

  // 1. Teste de Registro
  logInfo('Testando registro de usuário...');
  const registerResponse = await makeRequest('POST', '/api/auth/register', testData.user);
  
  if (registerResponse.ok) {
    logSuccess('Registro realizado com sucesso');
    testUserId = registerResponse.data.user?.id;
    authToken = registerResponse.data.token;
  } else {
    logWarning(`Registro falhou (pode ser usuário existente): ${registerResponse.data?.message || 'Erro desconhecido'}`);
  }

  // 2. Teste de Login
  logInfo('Testando login...');
  const loginResponse = await makeRequest('POST', '/api/auth/login', {
    email: testData.user.email,
    password: testData.user.password
  });

  if (loginResponse.ok) {
    logSuccess('Login realizado com sucesso');
    authToken = loginResponse.data.token;
    testUserId = loginResponse.data.user?.id;
  } else {
    logError(`Login falhou: ${loginResponse.data?.message || 'Erro desconhecido'}`);
    return false;
  }

  return true;
}

// Testes de Recuperação de Senha
async function testPasswordRecovery() {
  logSection('TESTES DE RECUPERAÇÃO DE SENHA');

  // 1. Teste de Solicitação de Reset
  logInfo('Testando solicitação de recuperação de senha...');
  const forgotResponse = await makeRequest('POST', '/api/auth/forgot-password', {
    email: testData.user.email
  });

  if (forgotResponse.ok) {
    logSuccess('Solicitação de recuperação enviada com sucesso');
    resetToken = forgotResponse.data.resetToken;
    logInfo(`Token gerado: ${resetToken.substring(0, 20)}...`);
  } else {
    logError(`Recuperação falhou: ${forgotResponse.data?.message || 'Erro desconhecido'}`);
    return false;
  }

  // 2. Teste de Verificação de Token
  if (resetToken) {
    logInfo('Testando verificação de token...');
    const verifyResponse = await makeRequest('GET', `/api/auth/verify-reset-token/${resetToken}`);
    
    if (verifyResponse.ok && verifyResponse.data.valid) {
      logSuccess(`Token válido para email: ${verifyResponse.data.email}`);
    } else {
      logError('Token inválido ou expirado');
      return false;
    }
  }

  // 3. Teste de Reset de Senha
  if (resetToken) {
    logInfo('Testando redefinição de senha...');
    const newPassword = 'novaSenha123';
    const resetResponse = await makeRequest('POST', '/api/auth/reset-password', {
      token: resetToken,
      newPassword: newPassword
    });

    if (resetResponse.ok) {
      logSuccess('Senha redefinida com sucesso');
      
      // Teste de login com nova senha
      logInfo('Testando login com nova senha...');
      const newLoginResponse = await makeRequest('POST', '/api/auth/login', {
        email: testData.user.email,
        password: newPassword
      });

      if (newLoginResponse.ok) {
        logSuccess('Login com nova senha funcionou');
        authToken = newLoginResponse.data.token;
        
        // Restaurar senha original para próximos testes
        logInfo('Restaurando senha original...');
        const restoreResponse = await makeRequest('POST', '/api/auth/forgot-password', {
          email: testData.user.email
        });
        
        if (restoreResponse.ok) {
          const newResetToken = restoreResponse.data.resetToken;
          await makeRequest('POST', '/api/auth/reset-password', {
            token: newResetToken,
            newPassword: testData.user.password
          });
          logSuccess('Senha original restaurada');
        }
      } else {
        logError('Login com nova senha falhou');
        return false;
      }
    } else {
      logError(`Reset de senha falhou: ${resetResponse.data?.message || 'Erro desconhecido'}`);
      return false;
    }
  }

  return true;
}

// Testes de Marketplace
async function testMarketplace() {
  logSection('TESTES DE MARKETPLACE');

  if (!authToken) {
    logError('Token de autenticação necessário para testes de marketplace');
    return false;
  }

  const authHeaders = { Authorization: `Bearer ${authToken}` };

  // 1. Teste de Listagem de Produtos
  logInfo('Testando listagem de produtos...');
  const productsResponse = await makeRequest('GET', '/api/marketplace/products');
  
  if (productsResponse.ok) {
    const products = productsResponse.data;
    logSuccess(`${products.length} produtos encontrados`);
    
    if (products.length > 0) {
      logInfo(`Primeiro produto: ${products[0].title}`);
    }
  } else {
    logError('Falha ao listar produtos');
    return false;
  }

  // 2. Teste de Categorias
  logInfo('Testando listagem de categorias...');
  const categoriesResponse = await makeRequest('GET', '/api/marketplace/categories');
  
  if (categoriesResponse.ok) {
    logSuccess(`${categoriesResponse.data.length} categorias encontradas`);
  } else {
    logWarning('Falha ao listar categorias');
  }

  // 3. Teste de Produtos Premium
  logInfo('Testando produtos premium...');
  const premiumResponse = await makeRequest('GET', '/api/marketplace/products?premium=true');
  
  if (premiumResponse.ok) {
    const premiumProducts = premiumResponse.data;
    logSuccess(`${premiumProducts.length} produtos premium encontrados`);
  } else {
    logWarning('Falha ao listar produtos premium');
  }

  return true;
}

// Testes de Downloads
async function testDownloads() {
  logSection('TESTES DE DOWNLOADS');

  if (!authToken) {
    logError('Token de autenticação necessário para testes de downloads');
    return false;
  }

  const authHeaders = { Authorization: `Bearer ${authToken}` };

  // 1. Teste de Biblioteca do Usuário
  logInfo('Testando biblioteca do usuário...');
  const libraryResponse = await makeRequest('GET', '/api/downloads/my-library', null, authHeaders);
  
  if (libraryResponse.ok) {
    logSuccess(`${libraryResponse.data.length} itens na biblioteca`);
  } else {
    logWarning('Falha ao acessar biblioteca do usuário');
  }

  // 2. Teste de Downloads Disponíveis
  logInfo('Testando downloads disponíveis...');
  const downloadsResponse = await makeRequest('GET', '/api/downloads', null, authHeaders);
  
  if (downloadsResponse.ok) {
    logSuccess(`${downloadsResponse.data.length} downloads disponíveis`);
  } else {
    logWarning('Falha ao listar downloads');
  }

  return true;
}

// Testes de Favoritos
async function testFavorites() {
  logSection('TESTES DE FAVORITOS');

  if (!authToken) {
    logError('Token de autenticação necessário para testes de favoritos');
    return false;
  }

  const authHeaders = { Authorization: `Bearer ${authToken}` };

  // 1. Teste de Listagem de Favoritos
  logInfo('Testando listagem de favoritos...');
  const favoritesResponse = await makeRequest('GET', '/api/favorites', null, authHeaders);
  
  if (favoritesResponse.ok) {
    logSuccess(`${favoritesResponse.data.length} favoritos encontrados`);
  } else {
    logWarning('Falha ao listar favoritos');
  }

  // 2. Teste de Adição/Remoção de Favorito (se houver produtos)
  const productsResponse = await makeRequest('GET', '/api/marketplace/products');
  
  if (productsResponse.ok && productsResponse.data.length > 0) {
    const testProduct = productsResponse.data[0];
    
    logInfo(`Testando adição de favorito (produto: ${testProduct.title})...`);
    const addFavoriteResponse = await makeRequest('POST', `/api/favorites/${testProduct.id}`, null, authHeaders);
    
    if (addFavoriteResponse.ok) {
      logSuccess('Favorito adicionado com sucesso');
      
      // Teste de remoção
      logInfo('Testando remoção de favorito...');
      const removeFavoriteResponse = await makeRequest('DELETE', `/api/favorites/${testProduct.id}`, null, authHeaders);
      
      if (removeFavoriteResponse.ok) {
        logSuccess('Favorito removido com sucesso');
      } else {
        logWarning('Falha ao remover favorito');
      }
    } else {
      logWarning('Falha ao adicionar favorito');
    }
  }

  return true;
}

// Testes de Dashboard
async function testDashboard() {
  logSection('TESTES DE DASHBOARD');

  if (!authToken) {
    logError('Token de autenticação necessário para testes de dashboard');
    return false;
  }

  const authHeaders = { Authorization: `Bearer ${authToken}` };

  // 1. Teste de Estatísticas
  logInfo('Testando estatísticas do dashboard...');
  const statsResponse = await makeRequest('GET', '/api/dashboard/stats', null, authHeaders);
  
  if (statsResponse.ok) {
    const stats = statsResponse.data;
    logSuccess('Estatísticas carregadas com sucesso');
    logInfo(`- Downloads: ${stats.totalDownloads || 0}`);
    logInfo(`- Favoritos: ${stats.totalFavorites || 0}`);
    logInfo(`- Compras: ${stats.totalPurchases || 0}`);
  } else {
    logWarning('Falha ao carregar estatísticas');
  }

  return true;
}

// Testes de CMS (se acessível)
async function testCMS() {
  logSection('TESTES DE CMS');

  // 1. Teste de Conteúdo Público
  logInfo('Testando conteúdo público do CMS...');
  const contentResponse = await makeRequest('GET', '/api/cms/content');
  
  if (contentResponse.ok) {
    logSuccess(`${contentResponse.data.length} itens de conteúdo encontrados`);
  } else {
    logWarning('Falha ao acessar conteúdo do CMS');
  }

  // 2. Teste de Configurações da Hero Section
  logInfo('Testando configurações da hero section...');
  const heroResponse = await makeRequest('GET', '/api/hero/config');
  
  if (heroResponse.ok) {
    logSuccess('Configurações da hero section carregadas');
  } else {
    logWarning('Falha ao carregar configurações da hero');
  }

  // 3. Teste de Artigos
  logInfo('Testando artigos...');
  const articlesResponse = await makeRequest('GET', '/api/articles');
  
  if (articlesResponse.ok) {
    logSuccess(`${articlesResponse.data.length} artigos encontrados`);
  } else {
    logWarning('Falha ao carregar artigos');
  }

  return true;
}

// Teste de Performance
async function testPerformance() {
  logSection('TESTES DE PERFORMANCE');

  const endpoints = [
    '/api/articles',
    '/api/marketplace/products',
    '/api/hero/config',
    '/api/cms/content'
  ];

  for (const endpoint of endpoints) {
    logInfo(`Testando performance de ${endpoint}...`);
    
    const startTime = Date.now();
    const response = await makeRequest('GET', endpoint);
    const endTime = Date.now();
    
    const responseTime = endTime - startTime;
    
    if (response.ok) {
      if (responseTime < 100) {
        logSuccess(`${endpoint}: ${responseTime}ms (Excelente)`);
      } else if (responseTime < 500) {
        logSuccess(`${endpoint}: ${responseTime}ms (Bom)`);
      } else {
        logWarning(`${endpoint}: ${responseTime}ms (Lento)`);
      }
    } else {
      logError(`${endpoint}: Falhou (${response.status})`);
    }
  }
}

// Função principal
async function runTests() {
  log('\n🚀 INICIANDO TESTES COMPLETOS DO SISTEMA', 'cyan', '');
  log(`Testando API em: ${API_BASE}`, 'dim');
  
  const results = {
    passed: 0,
    failed: 0,
    warnings: 0
  };

  try {
    // Executar todos os testes
    const tests = [
      { name: 'Autenticação', fn: testAuthentication },
      { name: 'Recuperação de Senha', fn: testPasswordRecovery },
      { name: 'Marketplace', fn: testMarketplace },
      { name: 'Downloads', fn: testDownloads },
      { name: 'Favoritos', fn: testFavorites },
      { name: 'Dashboard', fn: testDashboard },
      { name: 'CMS', fn: testCMS },
      { name: 'Performance', fn: testPerformance }
    ];

    for (const test of tests) {
      try {
        const result = await test.fn();
        if (result) {
          results.passed++;
        } else {
          results.failed++;
        }
      } catch (error) {
        logError(`Erro no teste ${test.name}: ${error.message}`);
        results.failed++;
      }
    }

    // Relatório final
    logSection('RELATÓRIO FINAL');
    logSuccess(`Testes passou: ${results.passed}`);
    
    if (results.failed > 0) {
      logError(`Testes falharam: ${results.failed}`);
    }
    
    if (results.warnings > 0) {
      logWarning(`Avisos: ${results.warnings}`);
    }

    const totalTests = results.passed + results.failed;
    const successRate = Math.round((results.passed / totalTests) * 100);
    
    log(`\nTaxa de Sucesso: ${successRate}%`, successRate >= 80 ? 'green' : successRate >= 60 ? 'yellow' : 'red');
    
    if (successRate >= 80) {
      logSuccess('Sistema funcionando corretamente! 🎉');
    } else if (successRate >= 60) {
      logWarning('Sistema funcionando com algumas limitações ⚠️');
    } else {
      logError('Sistema com problemas significativos ❌');
    }

  } catch (error) {
    logError(`Erro geral nos testes: ${error.message}`);
  }
}

// Verificar se fetch está disponível (Node.js 18+)
if (typeof fetch === 'undefined') {
  logError('Este script requer Node.js 18+ ou uma implementação de fetch');
  logInfo('Instalando node-fetch como alternativa...');
  
  try {
    const { default: fetch } = await import('node-fetch');
    global.fetch = fetch;
  } catch (error) {
    logError('Instale node-fetch: npm install node-fetch');
    process.exit(1);
  }
}

// Executar testes
runTests().catch(error => {
  logError(`Erro fatal: ${error.message}`);
  process.exit(1);
});