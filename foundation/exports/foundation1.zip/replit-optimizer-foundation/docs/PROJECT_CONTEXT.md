# duEuler Platform - Marketplace Digital

## Overview

The duEuler Platform is a comprehensive digital marketplace and content management system built as a modern web application. It evolved from a basic institutional website into an advanced digital platform with multiple functionalities including user authentication, content management, e-commerce capabilities, and a full CMS administrative interface.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with ShadCN/UI component library
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for client-side routing
- **Animations**: Framer Motion for smooth transitions and interactions
- **Forms**: React Hook Form with Zod validation
- **Payment Processing**: Stripe Elements integration

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript throughout
- **Authentication**: JWT tokens with bcrypt password hashing
- **Database**: PostgreSQL with Drizzle ORM
- **File Uploads**: Multer middleware
- **Email Service**: SendGrid integration for transactional emails

### Database Design
- **ORM**: Drizzle with PostgreSQL
- **Schema Management**: Centralized in `shared/schema.ts`
- **Multi-user System**: Separate tables for admin users and platform users
- **Content Management**: Flexible CMS structure for dynamic content
- **E-commerce**: Product management with Stripe integration

## Key Components

### Authentication System
- **Multi-level Authentication**: Admin users and platform users (customers/creators)
- **Dynamic User Upgrade**: Users can upgrade from customer to creator via dashboard
- **Password Recovery**: Complete forgot/reset password flow with secure tokens
- **JWT Security**: 1-hour expiration tokens for password resets
- **Protected Routes**: Middleware-based route protection

### Content Management System (CMS)
- **Dynamic Sections**: Hero carousel, services, about, contact, how-it-works
- **Article Management**: Blog posts and knowledge base articles
- **Media Library**: File upload and management system
- **Configuration-based**: JSON configuration files for easy content updates

### Marketplace Features
- **Product Catalog**: Digital products with categories and pricing
- **Secure Downloads**: Token-based download protection with expiration
- **Payment Processing**: Stripe integration for secure transactions
- **User Library**: Personal download library for purchased content

### Landing Page System
- **Responsive Design**: Mobile-first approach with breakpoint optimization
- **Interactive Elements**: 3D animations with Three.js integration
- **Dynamic Content**: API-driven sections with real-time updates
- **Performance Optimized**: All APIs respond under 80ms

## Data Flow

### User Registration/Authentication Flow
1. User registers with email/password
2. Password hashed with bcrypt
3. JWT token generated and returned
4. Token stored in localStorage for session management
5. Protected routes verify token on each request

### Content Delivery Flow
1. CMS admin updates content through admin interface
2. Content stored in PostgreSQL database
3. API endpoints serve content to frontend
4. React components render dynamic content
5. Caching layer ensures optimal performance

### E-commerce Flow
1. User browses marketplace products
2. Product selection triggers Stripe checkout
3. Payment processed securely through Stripe
4. Purchase recorded in database
5. Download tokens generated for immediate access

## External Dependencies

### Core Dependencies
- **Database**: PostgreSQL (Neon serverless)
- **Payment Processing**: Stripe API
- **Email Service**: SendGrid
- **File Storage**: Local filesystem (uploads directory)

### Development Dependencies
- **Build Tool**: Vite for fast development and optimized builds
- **Type Safety**: TypeScript throughout the stack
- **Code Quality**: ESLint and Prettier (implicit)
- **Testing**: Custom test scripts for system validation

### Third-party Integrations
- **Stripe**: Payment processing and subscription management
- **SendGrid**: Transactional email delivery
- **Three.js**: 3D animations and interactive elements

## Deployment Strategy

### Environment Configuration
- **Development**: Local development with hot reloading
- **Production**: Node.js server with static file serving
- **Database**: Environment-specific PostgreSQL connections
- **Secrets Management**: Environment variables for API keys

### Build Process
1. Frontend built with Vite (optimized bundles)
2. Backend compiled with esbuild (ES modules)
3. Static files served from dist/public
4. Server runs from compiled dist/index.js

### Scaling Considerations
- **Database**: PostgreSQL with connection pooling
- **File Storage**: Ready for migration to cloud storage
- **CDN**: Static assets can be moved to CDN
- **Load Balancing**: Express server ready for horizontal scaling

## User Preferences

Preferred communication style: Simple, everyday language.

## Development Rules & Compatibility Standards

### Database Structure Integrity
- **NEVER modify existing table structures** without explicit user approval
- **NEVER rename columns** in production tables (platform_users, etc.)
- **NEVER drop or alter constraints** on existing fields
- Always use `ADD COLUMN IF NOT EXISTS` for new fields
- Maintain backward compatibility with existing systems

### Naming Conventions & Consistency
- Follow existing naming patterns in the codebase
- Use consistent field names across related tables
- Maintain existing API endpoint structures
- Preserve existing response formats unless explicitly requested

### Implementation Safety Rules
- **ALWAYS verify existing implementations first**: Before creating any new table, function, or feature, search the entire codebase and database schema to identify existing similar implementations
- **Reuse existing infrastructure**: Use existing tables, functions, and patterns whenever possible rather than duplicating functionality
- **Check database schema thoroughly**: Use SQL queries to inspect existing tables and their structures before creating new ones
- **Search codebase systematically**: Use search tools to find existing implementations of similar features
- Test all changes in isolation before affecting core systems
- Document any structural changes with clear rollback procedures
- Verify compatibility with existing authentication and user management
- Always check impact on related components before modifications

### Code Quality Standards
- Follow established patterns in existing codebase
- Maintain type safety and schema consistency
- Preserve existing error handling and validation
- Keep API contracts stable unless versioning is implemented

## Recent Changes

- **Foundation Template Finalizado**: Sistema completo de otimização implementado e validado com 100% de aprovação (Janeiro 28, 2025)
- **Foundation ZIP Gerado**: Pacote completo (100K) criado para reuso em futuros projetos com documentação, testes, scripts e códigos (Janeiro 28, 2025)
- **Validação Completa Executada**: 18/18 verificações aprovadas incluindo testes, Docker, ML, dashboard e APIs funcionais (Janeiro 28, 2025)
- **Guia Completo Expandido**: 5.353+ linhas de documentação técnica com logs de comandos, erros resolvidos e implementações (Janeiro 28, 2025)
- **Sistema de Scripts Automação**: 3 scripts funcionais criados para testes, Docker e geração de foundation (Janeiro 28, 2025)
- **Dashboard Analytics React**: 558 linhas implementadas com WebSocket, gráficos em tempo real e sistema de alertas (Janeiro 28, 2025)
- **Sistema ML Python**: 395 linhas com Random Forest/Gradient Boosting para predição de custos (Janeiro 28, 2025)
- **Pipeline CI/CD GitHub Actions**: Configuração completa para integração contínua e deploy automatizado (Janeiro 28, 2025)
- **Professional Area Authentication Fixed**: Resolved critical JWT authentication errors in professional modals by correcting token retrieval from localStorage ('auth_token' instead of 'token') and fixing JWT_SECRET consistency (June 26, 2025)
- **Professional Availability System Operational**: Complete availability configuration system working with successful API integration, supporting weekly/daily/monthly patterns and flexible time intervals (June 26, 2025)
- **Professional Services Management**: Service configuration modal fully functional with proper authentication, supporting all service types (physical, online, chat, Q&A) and pricing models (June 26, 2025)
- **Database Schema Updates**: Successfully added availabilityConfig field to professionals table with proper PostgreSQL integration for storing complex availability patterns (June 26, 2025)

## Cost Optimization System

A comprehensive cost optimization system for Replit development has been documented with:
- **Central Configuration Engine**: Rule-based system with file matching, keyword detection, and automated validation
- **Security and Validation**: Complete backup/recovery system with checksum validation and rollback capabilities
- **Error Recovery**: Advanced error handling with retry mechanisms, circuit breakers, and automatic recovery strategies
- **Missing Critical Components**: 17 identified gaps including microservices architecture, ML cost prediction, and enterprise compliance

## Changelog

Changelog:
- June 24, 2025. Initial setup
- June 25, 2025. Implemented dynamic user type upgrade system
- January 28, 2025. Completed comprehensive Replit cost optimization system documentation