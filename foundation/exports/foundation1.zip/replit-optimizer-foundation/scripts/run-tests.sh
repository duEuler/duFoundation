#!/bin/bash

# Script de Execução de Testes - Sistema de Otimização Replit
# Data: 28/01/2025
# Versão: 1.0

set -e

echo "🧪 Iniciando execução completa de testes..."
echo "Data: $(date)"
echo "===================================="

# Função para log colorido
log_success() {
    echo -e "\033[32m✅ $1\033[0m"
}

log_error() {
    echo -e "\033[31m❌ $1\033[0m"
}

log_info() {
    echo -e "\033[34mℹ️  $1\033[0m"
}

log_warning() {
    echo -e "\033[33m⚠️  $1\033[0m"
}

# Verificar dependências
log_info "Verificando dependências..."

if ! command -v node &> /dev/null; then
    log_error "Node.js não encontrado"
    exit 1
fi

if ! command -v npm &> /dev/null; then
    log_error "NPM não encontrado"
    exit 1
fi

log_success "Node.js $(node --version) encontrado"
log_success "NPM $(npm --version) encontrado"

# Verificar se as dependências estão instaladas
log_info "Verificando dependências do projeto..."

if [ ! -d "node_modules" ]; then
    log_warning "node_modules não encontrado, instalando dependências..."
    npm install
fi

# Verificar se vitest está disponível
if ! npm list vitest &> /dev/null; then
    log_error "Vitest não está instalado"
    exit 1
fi

log_success "Dependências verificadas"

# Executar testes unitários
echo ""
log_info "Executando testes unitários..."

if npx vitest run tests/ --reporter=verbose; then
    log_success "Testes unitários passaram"
else
    log_error "Falha nos testes unitários"
    exit 1
fi

# Executar verificação de tipos TypeScript
echo ""
log_info "Verificando tipos TypeScript..."

if npx tsc --noEmit; then
    log_success "Verificação de tipos passou"
else
    log_warning "Verificação de tipos falhou, mas continuando..."
fi

# Executar linting
echo ""
log_info "Executando linting..."

if npm run lint 2>/dev/null || true; then
    log_success "Linting concluído"
else
    log_warning "Linting não configurado, pulando..."
fi

# Testar conexão com banco de dados
echo ""
log_info "Testando conectividade do sistema..."

if curl -f http://localhost:5000/api/sectors &> /dev/null; then
    log_success "API do sistema respondendo"
else
    log_warning "API do sistema não está respondendo"
fi

# Gerar relatório de cobertura
echo ""
log_info "Gerando relatório de cobertura..."

if npx vitest run --coverage 2>/dev/null || true; then
    log_success "Relatório de cobertura gerado"
else
    log_warning "Cobertura não configurada, pulando..."
fi

# Resumo final
echo ""
echo "===================================="
log_success "Execução de testes concluída!"
echo "Data: $(date)"
echo "===================================="

# Salvar log
echo "Log salvo em: test-results-$(date +%Y%m%d-%H%M%S).log"