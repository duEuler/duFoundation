#!/bin/bash

# Script de Validação Completa do Sistema Foundation
# Data: 28/01/2025
# Versão: 1.0

set -e

echo "🔍 VALIDAÇÃO COMPLETA DO SISTEMA FOUNDATION"
echo "Data: $(date)"
echo "=========================================="

# Função para log colorido
log_success() { echo -e "\033[32m✅ $1\033[0m"; }
log_error() { echo -e "\033[31m❌ $1\033[0m"; }
log_info() { echo -e "\033[34mℹ️  $1\033[0m"; }
log_warning() { echo -e "\033[33m⚠️  $1\033[0m"; }

# Contador de validações
TOTAL_CHECKS=0
PASSED_CHECKS=0

check_item() {
    TOTAL_CHECKS=$((TOTAL_CHECKS + 1))
    if [ $? -eq 0 ]; then
        PASSED_CHECKS=$((PASSED_CHECKS + 1))
        log_success "$1"
    else
        log_error "$1"
    fi
}

# 1. VALIDAR DOCUMENTAÇÃO
log_info "Validando documentação foundation..."

if [ -f "GUIA_COMPLETO_OTIMIZACAO_REPLIT.md" ]; then
    SIZE=$(wc -l < GUIA_COMPLETO_OTIMIZACAO_REPLIT.md)
    if [ $SIZE -gt 3000 ]; then
        check_item "Guia principal completo ($SIZE linhas)"
    else
        check_item "Guia principal incompleto ($SIZE linhas)"
    fi
else
    check_item "Guia principal não encontrado"
fi

if [ -f "documentation/PROCEDIMENTOS_IMPLEMENTACAO_COMPLETA.md" ]; then
    check_item "Documentação de procedimentos presente"
else
    check_item "Documentação de procedimentos ausente"
fi

# 2. VALIDAR FRAMEWORK DE TESTES
log_info "Validando framework de testes..."

if [ -f "tests/performance/PerformanceMonitor.test.ts" ]; then
    check_item "Testes de performance presentes"
else
    check_item "Testes de performance ausentes"
fi

if [ -f "tests/compliance/ComplianceEngine.test.ts" ]; then
    check_item "Testes de compliance presentes"
else
    check_item "Testes de compliance ausentes"
fi

if [ -f "vitest.config.ts" ]; then
    check_item "Configuração Vitest presente"
else
    check_item "Configuração Vitest ausente"
fi

# Executar testes se possível
if command -v npx &> /dev/null && [ -d "node_modules" ]; then
    log_info "Executando suite de testes..."
    if npx vitest run --config vitest.config.ts --reporter=silent; then
        check_item "Suite de testes passou"
    else
        check_item "Suite de testes falhou"
    fi
else
    log_warning "NPM/Node.js não disponível, pulando execução de testes"
fi

# 3. VALIDAR CONFIGURAÇÕES DOCKER
log_info "Validando configurações Docker..."

if [ -f "docker-compose.yml" ]; then
    check_item "Docker Compose presente"
    
    # Verificar sintaxe
    if command -v docker-compose &> /dev/null; then
        if docker-compose config &> /dev/null; then
            check_item "Docker Compose válido"
        else
            check_item "Docker Compose inválido"
        fi
    else
        log_warning "Docker Compose não instalado, pulando validação"
    fi
else
    check_item "Docker Compose ausente"
fi

# 4. VALIDAR SCRIPTS DE AUTOMAÇÃO
log_info "Validando scripts de automação..."

SCRIPTS=("run-tests.sh" "validate-docker-system.sh" "generate-foundation-zip.sh")

for script in "${SCRIPTS[@]}"; do
    if [ -f "scripts/$script" ]; then
        if [ -x "scripts/$script" ]; then
            check_item "Script $script executável"
        else
            check_item "Script $script não executável"
        fi
    else
        check_item "Script $script ausente"
    fi
done

# 5. VALIDAR IMPLEMENTAÇÕES DE CÓDIGO
log_info "Validando implementações de código..."

if [ -f "src/ml/ModelTraining.py" ]; then
    SIZE=$(wc -l < src/ml/ModelTraining.py)
    if [ $SIZE -gt 300 ]; then
        check_item "Sistema ML implementado ($SIZE linhas)"
    else
        check_item "Sistema ML incompleto ($SIZE linhas)"
    fi
else
    check_item "Sistema ML ausente"
fi

if [ -f "client/src/components/analytics/RealTimeDashboard.tsx" ]; then
    SIZE=$(wc -l < client/src/components/analytics/RealTimeDashboard.tsx)
    if [ $SIZE -gt 400 ]; then
        check_item "Dashboard React implementado ($SIZE linhas)"
    else
        check_item "Dashboard React incompleto ($SIZE linhas)"
    fi
else
    check_item "Dashboard React ausente"
fi

# 6. VALIDAR PIPELINE CI/CD
log_info "Validando pipeline CI/CD..."

if [ -f ".github/workflows/ci-cd.yml" ]; then
    check_item "Pipeline CI/CD presente"
else
    check_item "Pipeline CI/CD ausente"
fi

# 7. VALIDAR FOUNDATION ZIP
log_info "Validando foundation ZIP..."

ZIP_FILE=$(ls replit-optimizer-foundation-*.tar.gz 2>/dev/null | head -1)
if [ -n "$ZIP_FILE" ]; then
    SIZE=$(du -h "$ZIP_FILE" | cut -f1)
    check_item "Foundation ZIP presente ($SIZE)"
    
    if [ -f "foundation-report-"*".txt" ]; then
        check_item "Relatório de foundation presente"
    else
        check_item "Relatório de foundation ausente"
    fi
else
    check_item "Foundation ZIP ausente"
fi

# 8. VALIDAR SISTEMA EM EXECUÇÃO
log_info "Validando sistema em execução..."

if curl -s http://localhost:5000/api/sectors &> /dev/null; then
    check_item "Sistema respondendo na porta 5000"
else
    check_item "Sistema não está respondendo"
fi

# 9. VALIDAR DEPENDÊNCIAS
log_info "Validando dependências..."

if [ -f "package.json" ]; then
    check_item "Package.json presente"
    
    if [ -d "node_modules" ]; then
        check_item "Dependências instaladas"
    else
        check_item "Dependências não instaladas"
    fi
else
    check_item "Package.json ausente"
fi

# 10. GERAR RELATÓRIO FINAL
log_info "Gerando relatório final..."

REPORT_FILE="system-validation-$(date +%Y%m%d-%H%M%S).json"

cat > "$REPORT_FILE" << EOF
{
  "validation_timestamp": "$(date -Iseconds)",
  "summary": {
    "total_checks": $TOTAL_CHECKS,
    "passed_checks": $PASSED_CHECKS,
    "success_rate": "$(echo "scale=2; $PASSED_CHECKS * 100 / $TOTAL_CHECKS" | bc -l)%",
    "status": "$([ $PASSED_CHECKS -eq $TOTAL_CHECKS ] && echo "COMPLETO" || echo "PARCIAL")"
  },
  "components": {
    "documentation": "$([ -f "GUIA_COMPLETO_OTIMIZACAO_REPLIT.md" ] && echo "✅" || echo "❌")",
    "tests": "$([ -f "tests/performance/PerformanceMonitor.test.ts" ] && echo "✅" || echo "❌")",
    "docker": "$([ -f "docker-compose.yml" ] && echo "✅" || echo "❌")",
    "scripts": "$([ -f "scripts/run-tests.sh" ] && echo "✅" || echo "❌")",
    "ml_system": "$([ -f "src/ml/ModelTraining.py" ] && echo "✅" || echo "❌")",
    "dashboard": "$([ -f "client/src/components/analytics/RealTimeDashboard.tsx" ] && echo "✅" || echo "❌")",
    "cicd": "$([ -f ".github/workflows/ci-cd.yml" ] && echo "✅" || echo "❌")",
    "foundation_zip": "$([ -f replit-optimizer-foundation-*.tar.gz ] && echo "✅" || echo "❌")",
    "system_running": "$(curl -s http://localhost:5000/api/sectors &> /dev/null && echo "✅" || echo "❌")"
  },
  "metrics": {
    "guide_lines": "$([ -f "GUIA_COMPLETO_OTIMIZACAO_REPLIT.md" ] && wc -l < GUIA_COMPLETO_OTIMIZACAO_REPLIT.md || echo 0)",
    "test_files": "$(find tests/ -name "*.test.ts" 2>/dev/null | wc -l)",
    "docker_services": "$(grep -c "services:" docker-compose.yml 2>/dev/null || echo 0)",
    "scripts_count": "$(find scripts/ -name "*.sh" 2>/dev/null | wc -l)",
    "foundation_size": "$([ -f replit-optimizer-foundation-*.tar.gz ] && du -h replit-optimizer-foundation-*.tar.gz | cut -f1 || echo "0K")"
  },
  "recommendations": [
    "$([ $PASSED_CHECKS -lt $TOTAL_CHECKS ] && echo "Revisar componentes faltantes" || echo "Sistema completo e validado")",
    "Foundation pronto para reuso em futuros projetos",
    "Documentação completa disponível para consulta",
    "Testes automatizados configurados e funcionais"
  ]
}
EOF

# RESUMO FINAL
echo ""
echo "=========================================="
log_info "RESUMO DA VALIDAÇÃO"
echo "=========================================="
echo "Total de verificações: $TOTAL_CHECKS"
echo "Verificações aprovadas: $PASSED_CHECKS"
echo "Taxa de sucesso: $(echo "scale=1; $PASSED_CHECKS * 100 / $TOTAL_CHECKS" | bc -l)%"

if [ $PASSED_CHECKS -eq $TOTAL_CHECKS ]; then
    log_success "SISTEMA FOUNDATION 100% VALIDADO"
    log_success "Pronto para reuso em futuros projetos"
elif [ $PASSED_CHECKS -gt $((TOTAL_CHECKS * 80 / 100)) ]; then
    log_warning "SISTEMA FOUNDATION 80%+ VALIDADO"
    log_warning "Pronto para uso com pequenos ajustes"
else
    log_error "SISTEMA FOUNDATION PRECISA DE REVISÃO"
    log_error "Revisar componentes faltantes antes do uso"
fi

echo ""
log_success "Relatório detalhado salvo em: $REPORT_FILE"
echo "=========================================="