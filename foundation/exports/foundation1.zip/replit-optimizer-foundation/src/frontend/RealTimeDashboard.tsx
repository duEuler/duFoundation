// client/src/components/analytics/RealTimeDashboard.tsx
import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { 
  LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell, BarChart, Bar
} from 'recharts';
import { 
  TrendingUp, TrendingDown, AlertTriangle, CheckCircle, 
  DollarSign, Zap, Activity, Users, Server, Clock
} from 'lucide-react';

interface RealTimeMetrics {
  cost: {
    current: number;
    trend: 'up' | 'down' | 'stable';
    change: number;
    prediction: number;
  };
  performance: {
    responseTime: number;
    throughput: number;
    errorRate: number;
    cpuUsage: number;
    memoryUsage: number;
  };
  optimizations: {
    active: number;
    completed: number;
    efficiency: number;
    totalSavings: number;
  };
  system: {
    uptime: number;
    activeUsers: number;
    operations: number;
    alerts: number;
  };
}

interface Alert {
  id: string;
  type: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  timestamp: number;
  acknowledged: boolean;
}

interface OptimizationEvent {
  id: string;
  operation: string;
  savings: number;
  duration: number;
  timestamp: number;
  efficiency: number;
}

export function RealTimeDashboard() {
  const [metrics, setMetrics] = useState<RealTimeMetrics | null>(null);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [recentOptimizations, setRecentOptimizations] = useState<OptimizationEvent[]>([]);
  const [costHistory, setCostHistory] = useState<any[]>([]);
  const [performanceHistory, setPerformanceHistory] = useState<any[]>([]);
  const [isConnected, setIsConnected] = useState(false);
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    connectWebSocket();
    
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  const connectWebSocket = () => {
    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.hostname}:8080`;
      
      wsRef.current = new WebSocket(wsUrl);

      wsRef.current.onopen = () => {
        console.log('Connected to analytics WebSocket');
        setIsConnected(true);
        setConnectionError(null);
        
        // Subscribe to real-time updates
        wsRef.current?.send(JSON.stringify({
          type: 'subscribe',
          channels: ['metrics', 'alerts', 'optimizations']
        }));
      };

      wsRef.current.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          handleWebSocketMessage(data);
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      };

      wsRef.current.onclose = () => {
        console.log('WebSocket connection closed');
        setIsConnected(false);
        
        // Attempt to reconnect after 5 seconds
        setTimeout(connectWebSocket, 5000);
      };

      wsRef.current.onerror = (error) => {
        console.error('WebSocket error:', error);
        setConnectionError('Failed to connect to analytics service');
        setIsConnected(false);
      };

    } catch (error) {
      console.error('Error creating WebSocket connection:', error);
      setConnectionError('WebSocket not supported');
    }
  };

  const handleWebSocketMessage = (data: any) => {
    switch (data.type) {
      case 'connection_established':
        setMetrics(data.data.currentMetrics);
        setCostHistory(data.data.costHistory || []);
        setPerformanceHistory(data.data.performanceHistory || []);
        break;

      case 'cost_update':
        setMetrics(prev => prev ? {
          ...prev,
          cost: {
            current: data.data.current,
            trend: data.data.trend,
            change: data.data.change,
            prediction: data.data.prediction
          }
        } : null);
        
        setCostHistory(prev => [
          ...prev.slice(-29), // Keep last 30 points
          {
            timestamp: data.timestamp,
            cost: data.data.current,
            prediction: data.data.prediction
          }
        ]);
        break;

      case 'performance_update':
        setMetrics(prev => prev ? {
          ...prev,
          performance: data.data
        } : null);
        
        setPerformanceHistory(prev => [
          ...prev.slice(-29),
          {
            timestamp: data.timestamp,
            responseTime: data.data.responseTime,
            throughput: data.data.throughput,
            errorRate: data.data.errorRate
          }
        ]);
        break;

      case 'optimization_completed':
        setRecentOptimizations(prev => [
          data.data,
          ...prev.slice(0, 9) // Keep last 10
        ]);
        
        setMetrics(prev => prev ? {
          ...prev,
          optimizations: {
            ...prev.optimizations,
            completed: prev.optimizations.completed + 1,
            totalSavings: prev.optimizations.totalSavings + data.data.savings
          }
        } : null);
        break;

      case 'alert':
        setAlerts(prev => [
          data.data,
          ...prev.slice(0, 19) // Keep last 20
        ]);
        break;

      case 'performance_anomaly':
        setAlerts(prev => [
          {
            id: `anomaly-${Date.now()}`,
            type: 'performance_anomaly',
            severity: data.anomaly.severity,
            message: `Performance anomaly detected: ${data.anomaly.description}`,
            timestamp: data.timestamp,
            acknowledged: false
          },
          ...prev.slice(0, 19)
        ]);
        break;
    }
  };

  const acknowledgeAlert = (alertId: string) => {
    setAlerts(prev => prev.map(alert => 
      alert.id === alertId ? { ...alert, acknowledged: true } : alert
    ));
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'USD'
    }).format(value);
  };

  const formatTime = (timestamp: number) => {
    return new Date(timestamp).toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'destructive';
      case 'high': return 'destructive';
      case 'medium': return 'secondary';
      case 'low': return 'outline';
      default: return 'outline';
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="h-4 w-4 text-red-500" />;
      case 'down': return <TrendingDown className="h-4 w-4 text-green-500" />;
      default: return <Activity className="h-4 w-4 text-blue-500" />;
    }
  };

  if (!metrics) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
              <p className="text-slate-600 dark:text-slate-400">Conectando ao sistema de analytics...</p>
              {connectionError && (
                <Alert className="mt-4">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription>{connectionError}</AlertDescription>
                </Alert>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 dark:text-white">
              Analytics em Tempo Real
            </h1>
            <p className="text-slate-600 dark:text-slate-400">
              Monitoramento e insights do sistema de otimização Replit
            </p>
          </div>
          
          <div className="flex items-center space-x-4">
            <Badge variant={isConnected ? "default" : "destructive"} className="flex items-center space-x-1">
              {isConnected ? <CheckCircle className="h-3 w-3" /> : <AlertTriangle className="h-3 w-3" />}
              <span>{isConnected ? 'Conectado' : 'Desconectado'}</span>
            </Badge>
            
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => window.location.reload()}
            >
              Atualizar
            </Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Custo Atual</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{formatCurrency(metrics.cost.current)}</div>
              <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                {getTrendIcon(metrics.cost.trend)}
                <span>{metrics.cost.change > 0 ? '+' : ''}{metrics.cost.change}%</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Eficiência</CardTitle>
              <Zap className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{(metrics.optimizations.efficiency * 100).toFixed(1)}%</div>
              <Progress value={metrics.optimizations.efficiency * 100} className="mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Tempo de Resposta</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{metrics.performance.responseTime}ms</div>
              <p className="text-xs text-muted-foreground">
                Throughput: {metrics.performance.throughput} ops/s
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Usuários Ativos</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{metrics.system.activeUsers}</div>
              <p className="text-xs text-muted-foreground">
                {metrics.system.operations} operações ativas
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Charts Row */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Cost Trend Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Tendência de Custos</CardTitle>
              <CardDescription>Custos vs Predições (últimos 30 pontos)</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={costHistory}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="timestamp" 
                    tickFormatter={(value) => formatTime(value)}
                  />
                  <YAxis tickFormatter={(value) => `$${value.toFixed(2)}`} />
                  <Tooltip 
                    labelFormatter={(value) => formatTime(value)}
                    formatter={(value: any) => [`$${value.toFixed(2)}`, '']}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="cost" 
                    stroke="#3b82f6" 
                    strokeWidth={2}
                    name="Custo Real"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="prediction" 
                    stroke="#ef4444" 
                    strokeDasharray="5 5"
                    name="Predição"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Performance Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Performance do Sistema</CardTitle>
              <CardDescription>Métricas de performance em tempo real</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={performanceHistory}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis 
                    dataKey="timestamp" 
                    tickFormatter={(value) => formatTime(value)}
                  />
                  <YAxis />
                  <Tooltip 
                    labelFormatter={(value) => formatTime(value)}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="responseTime" 
                    stackId="1"
                    stroke="#10b981" 
                    fill="#10b981"
                    fillOpacity={0.6}
                    name="Tempo de Resposta (ms)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>

        {/* Alerts and Recent Optimizations */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Active Alerts */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <AlertTriangle className="h-5 w-5" />
                <span>Alertas Ativos</span>
                <Badge variant="secondary">{alerts.filter(a => !a.acknowledged).length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-80 overflow-y-auto">
                {alerts.filter(a => !a.acknowledged).length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <CheckCircle className="h-12 w-12 mx-auto mb-2 text-green-500" />
                    <p>Nenhum alerta ativo</p>
                  </div>
                ) : (
                  alerts.filter(a => !a.acknowledged).map(alert => (
                    <div key={alert.id} className="flex items-start space-x-3 p-3 border rounded-lg">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2 mb-1">
                          <Badge variant={getSeverityColor(alert.severity) as any}>
                            {alert.severity}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {formatTime(alert.timestamp)}
                          </span>
                        </div>
                        <p className="text-sm">{alert.message}</p>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => acknowledgeAlert(alert.id)}
                      >
                        OK
                      </Button>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Recent Optimizations */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Zap className="h-5 w-5" />
                <span>Otimizações Recentes</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3 max-h-80 overflow-y-auto">
                {recentOptimizations.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Activity className="h-12 w-12 mx-auto mb-2" />
                    <p>Nenhuma otimização recente</p>
                  </div>
                ) : (
                  recentOptimizations.map(opt => (
                    <div key={opt.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex-1">
                        <p className="font-medium text-sm">{opt.operation}</p>
                        <div className="flex items-center space-x-4 text-xs text-muted-foreground mt-1">
                          <span>Economia: {formatCurrency(opt.savings)}</span>
                          <span>Duração: {opt.duration}s</span>
                          <span>{formatTime(opt.timestamp)}</span>
                        </div>
                      </div>
                      <Badge variant="outline">
                        {(opt.efficiency * 100).toFixed(1)}%
                      </Badge>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* System Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Server className="h-5 w-5" />
              <span>Status do Sistema</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600">
                  {(metrics.system.uptime * 100).toFixed(2)}%
                </div>
                <p className="text-sm text-muted-foreground">Uptime</p>
              </div>
              
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">
                  {metrics.performance.cpuUsage}%
                </div>
                <p className="text-sm text-muted-foreground">CPU</p>
              </div>
              
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-600">
                  {metrics.performance.memoryUsage}%
                </div>
                <p className="text-sm text-muted-foreground">Memória</p>
              </div>
              
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-600">
                  {(metrics.performance.errorRate * 100).toFixed(2)}%
                </div>
                <p className="text-sm text-muted-foreground">Taxa de Erro</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}