/**
 * Sistema de Logs Centralizados - ELK Stack Integration
 * Foundation: Replit Cost Optimizer
 * Data: 28/01/2025
 */

export interface LogEntry {
  timestamp: Date;
  level: 'error' | 'warn' | 'info' | 'debug';
  message: string;
  service: string;
  environment: string;
  userId?: string;
  requestId?: string;
  metadata?: Record<string, any>;
  performance?: {
    duration: number;
    memory: number;
    cpu: number;
  };
  error?: {
    name: string;
    message: string;
    stack: string;
    code?: string;
  };
}

export interface LogQuery {
  service?: string;
  level?: string;
  startTime?: Date;
  endTime?: Date;
  userId?: string;
  search?: string;
  limit?: number;
}

export class CentralizedLoggingService {
  private indexPattern: string = 'replit-optimizer-logs';
  private environment: string;
  private logBuffer: LogEntry[] = [];
  private flushInterval: NodeJS.Timeout;

  constructor() {
    this.environment = process.env.NODE_ENV || 'development';
    this.startLogFlushing();
  }

  private startLogFlushing(): void {
    // Flush logs a cada 5 segundos
    this.flushInterval = setInterval(() => {
      this.flushLogs();
    }, 5000);
  }

  /**
   * Log de informações gerais
   */
  async info(message: string, metadata: Partial<LogEntry> = {}): Promise<void> {
    const logEntry = this.createLogEntry('info', message, metadata);
    await this.sendLog(logEntry);
  }

  /**
   * Log de avisos
   */
  async warn(message: string, metadata: Partial<LogEntry> = {}): Promise<void> {
    const logEntry = this.createLogEntry('warn', message, metadata);
    await this.sendLog(logEntry);
  }

  /**
   * Log de erros
   */
  async error(message: string, error?: Error, metadata: Partial<LogEntry> = {}): Promise<void> {
    const logEntry = this.createLogEntry('error', message, {
      ...metadata,
      error: error ? {
        name: error.name,
        message: error.message,
        stack: error.stack || '',
        code: (error as any).code
      } : undefined
    });
    await this.sendLog(logEntry);
  }

  /**
   * Log de debug
   */
  async debug(message: string, metadata: Partial<LogEntry> = {}): Promise<void> {
    const logEntry = this.createLogEntry('debug', message, metadata);
    await this.sendLog(logEntry);
  }

  /**
   * Log de performance
   */
  async performance(operation: string, duration: number, metadata: Partial<LogEntry> = {}): Promise<void> {
    const memoryUsage = process.memoryUsage();
    const cpuUsage = process.cpuUsage();
    
    const logEntry = this.createLogEntry('info', `Performance: ${operation}`, {
      ...metadata,
      performance: {
        duration,
        memory: memoryUsage.heapUsed,
        cpu: (cpuUsage.user + cpuUsage.system) / 1000000
      }
    });
    await this.sendLog(logEntry);
  }

  /**
   * Buscar logs (simulação para desenvolvimento)
   */
  async searchLogs(query: LogQuery): Promise<LogEntry[]> {
    try {
      // Em desenvolvimento, retorna logs do buffer
      let results = [...this.logBuffer];

      if (query.service) {
        results = results.filter(log => log.service === query.service);
      }

      if (query.level) {
        results = results.filter(log => log.level === query.level);
      }

      if (query.userId) {
        results = results.filter(log => log.userId === query.userId);
      }

      if (query.search && query.search.length > 0) {
        const searchTerm = query.search;
        results = results.filter(log => 
          log.message.includes(searchTerm) ||
          JSON.stringify(log.metadata || {}).includes(searchTerm)
        );
      }

      if (query.startTime) {
        results = results.filter(log => log.timestamp >= query.startTime!);
      }

      if (query.endTime) {
        results = results.filter(log => log.timestamp <= query.endTime!);
      }

      return results
        .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
        .slice(0, query.limit || 100);
    } catch (error) {
      console.error('Error searching logs:', error);
      return [];
    }
  }

  /**
   * Obter estatísticas de logs
   */
  async getLogStatistics(timeRange: { start: Date; end: Date }): Promise<{
    totalLogs: number;
    errorCount: number;
    warnCount: number;
    infoCount: number;
    debugCount: number;
    serviceBreakdown: Record<string, number>;
    performanceMetrics: {
      avgDuration: number;
      avgMemory: number;
      avgCpu: number;
    };
  }> {
    try {
      const relevantLogs = this.logBuffer.filter(log => 
        log.timestamp >= timeRange.start && log.timestamp <= timeRange.end
      );

      const levelCounts = relevantLogs.reduce(
        (acc, log) => {
          acc[log.level] = (acc[log.level] || 0) + 1;
          return acc;
        },
        { error: 0, warn: 0, info: 0, debug: 0 } as Record<string, number>
      );

      const serviceBreakdown = relevantLogs.reduce(
        (acc, log) => {
          acc[log.service] = (acc[log.service] || 0) + 1;
          return acc;
        },
        {} as Record<string, number>
      );

      const performanceLogs = relevantLogs.filter(log => log.performance);
      const avgDuration = performanceLogs.length > 0 
        ? performanceLogs.reduce((sum, log) => sum + (log.performance?.duration || 0), 0) / performanceLogs.length
        : 0;
      const avgMemory = performanceLogs.length > 0
        ? performanceLogs.reduce((sum, log) => sum + (log.performance?.memory || 0), 0) / performanceLogs.length
        : 0;
      const avgCpu = performanceLogs.length > 0
        ? performanceLogs.reduce((sum, log) => sum + (log.performance?.cpu || 0), 0) / performanceLogs.length
        : 0;

      return {
        totalLogs: relevantLogs.length,
        errorCount: levelCounts.error,
        warnCount: levelCounts.warn,
        infoCount: levelCounts.info,
        debugCount: levelCounts.debug,
        serviceBreakdown,
        performanceMetrics: {
          avgDuration,
          avgMemory,
          avgCpu
        }
      };
    } catch (error) {
      console.error('Error getting log statistics:', error);
      return {
        totalLogs: 0,
        errorCount: 0,
        warnCount: 0,
        infoCount: 0,
        debugCount: 0,
        serviceBreakdown: {},
        performanceMetrics: {
          avgDuration: 0,
          avgMemory: 0,
          avgCpu: 0
        }
      };
    }
  }

  /**
   * Configurar alertas baseados em logs
   */
  async setupLogAlerts(): Promise<void> {
    const alertConfigs = [
      {
        name: 'High Error Rate',
        condition: 'error_rate > 5%',
        timeWindow: '5m',
        actions: ['console', 'file']
      },
      {
        name: 'Performance Degradation',
        condition: 'avg_duration > 2000ms',
        timeWindow: '10m',
        actions: ['console']
      },
      {
        name: 'Service Down',
        condition: 'no_logs_received',
        timeWindow: '2m',
        actions: ['console', 'file']
      }
    ];

    for (const alert of alertConfigs) {
      console.log(`Alert configured: ${alert.name} - ${alert.condition}`);
    }
  }

  /**
   * Flush dos logs para persistência
   */
  private async flushLogs(): Promise<void> {
    if (this.logBuffer.length === 0) return;

    try {
      // Em ambiente de desenvolvimento, salva em arquivo
      if (this.environment === 'development') {
        const fs = require('fs').promises;
        const logData = this.logBuffer.map(log => JSON.stringify(log)).join('\n') + '\n';
        
        await fs.appendFile('logs/application.log', logData).catch(async () => {
          // Criar diretório se não existir
          require('fs').mkdirSync('logs', { recursive: true });
          return await fs.appendFile('logs/application.log', logData);
        });
      }

      // Limitar buffer a 1000 entradas
      if (this.logBuffer.length > 1000) {
        this.logBuffer = this.logBuffer.slice(-1000);
      }
    } catch (error) {
      console.error('Failed to flush logs:', error);
    }
  }

  private createLogEntry(level: LogEntry['level'], message: string, metadata: Partial<LogEntry>): LogEntry {
    return {
      timestamp: new Date(),
      level,
      message,
      service: metadata.service || 'unknown',
      environment: this.environment,
      userId: metadata.userId,
      requestId: metadata.requestId || this.generateRequestId(),
      metadata: metadata.metadata,
      performance: metadata.performance,
      error: metadata.error
    };
  }

  private async sendLog(logEntry: LogEntry): Promise<void> {
    try {
      // Adicionar ao buffer
      this.logBuffer.push(logEntry);

      // Log no console com formatação
      const timestamp = logEntry.timestamp.toISOString();
      const level = logEntry.level.toUpperCase().padEnd(5);
      const service = logEntry.service.padEnd(10);
      const message = logEntry.message;
      const metadata = logEntry.metadata ? ` | ${JSON.stringify(logEntry.metadata)}` : '';
      
      console.log(`${timestamp} [${service}] ${level}: ${message}${metadata}`);

      // Se for erro, mostrar stack trace
      if (logEntry.error?.stack) {
        console.error(logEntry.error.stack);
      }
    } catch (error) {
      console.error('Failed to send log:', error);
    }
  }

  private generateRequestId(): string {
    return `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Cleanup
   */
  destroy(): void {
    if (this.flushInterval) {
      clearInterval(this.flushInterval);
    }
    this.flushLogs();
  }
}

// Instância singleton
export const loggingService = new CentralizedLoggingService();

// Middleware para Express
export const loggingMiddleware = (req: any, res: any, next: any) => {
  const startTime = Date.now();
  const requestId = `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  
  req.requestId = requestId;
  
  // Log da requisição
  loggingService.info(`${req.method} ${req.path}`, {
    service: 'api',
    requestId,
    userId: req.user?.id,
    metadata: {
      method: req.method,
      path: req.path,
      userAgent: req.get('User-Agent'),
      ip: req.ip,
      query: req.query
    }
  });

  // Hook no response
  res.on('finish', () => {
    const duration = Date.now() - startTime;
    
    loggingService.performance(`${req.method} ${req.path}`, duration, {
      service: 'api',
      requestId,
      userId: req.user?.id,
      metadata: {
        statusCode: res.statusCode,
        contentLength: res.get('Content-Length')
      }
    });

    if (res.statusCode >= 400) {
      loggingService.error(`HTTP ${res.statusCode} - ${req.method} ${req.path}`, undefined, {
        service: 'api',
        requestId,
        userId: req.user?.id,
        metadata: {
          statusCode: res.statusCode,
          method: req.method,
          path: req.path
        }
      });
    }
  });

  next();
};