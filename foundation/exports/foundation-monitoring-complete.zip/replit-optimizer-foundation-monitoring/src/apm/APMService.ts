/**
 * Application Performance Monitoring (APM) Service
 * Foundation: Replit Cost Optimizer
 * Data: 28/01/2025
 */

export interface APMMetrics {
  timestamp: Date;
  service: string;
  operation: string;
  duration: number;
  statusCode?: number;
  success: boolean;
  errorMessage?: string;
  userAgent?: string;
  userId?: string;
  requestId?: string;
  resourceUsage: {
    cpuUsage: number;
    memoryUsage: number;
    diskUsage: number;
    networkIO: number;
  };
  customMetrics?: Record<string, number>;
}

export interface PerformanceThresholds {
  responseTime: {
    warning: number;
    critical: number;
  };
  errorRate: {
    warning: number;
    critical: number;
  };
  throughput: {
    minimum: number;
  };
  resourceUsage: {
    cpu: number;
    memory: number;
    disk: number;
  };
}

export interface APMAlert {
  id: string;
  type: 'performance' | 'error' | 'resource' | 'availability';
  severity: 'info' | 'warning' | 'critical';
  message: string;
  timestamp: Date;
  service: string;
  operation?: string;
  metrics: Record<string, number>;
  resolved: boolean;
}

export class APMService {
  private metrics: APMMetrics[] = [];
  private alerts: APMAlert[] = [];
  private thresholds: PerformanceThresholds;
  private monitoringInterval: NodeJS.Timeout;
  private isMonitoring: boolean = false;

  constructor() {
    this.thresholds = {
      responseTime: {
        warning: 1000, // 1 segundo
        critical: 3000  // 3 segundos
      },
      errorRate: {
        warning: 0.05,  // 5%
        critical: 0.10  // 10%
      },
      throughput: {
        minimum: 10     // 10 req/min mínimo
      },
      resourceUsage: {
        cpu: 80,       // 80%
        memory: 85,    // 85%
        disk: 90       // 90%
      }
    };
  }

  /**
   * Iniciar monitoramento
   */
  startMonitoring(): void {
    if (this.isMonitoring) return;

    this.isMonitoring = true;
    
    // Monitoramento a cada 30 segundos
    this.monitoringInterval = setInterval(() => {
      this.collectSystemMetrics();
      this.analyzeMetrics();
      this.checkAlerts();
    }, 30000);

    console.log('APM Monitoring started');
  }

  /**
   * Parar monitoramento
   */
  stopMonitoring(): void {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
    }
    this.isMonitoring = false;
    console.log('APM Monitoring stopped');
  }

  /**
   * Registrar métrica de operação
   */
  recordOperation(
    service: string,
    operation: string,
    duration: number,
    success: boolean,
    metadata: Partial<APMMetrics> = {}
  ): void {
    const metric: APMMetrics = {
      timestamp: new Date(),
      service,
      operation,
      duration,
      success,
      statusCode: metadata.statusCode,
      errorMessage: metadata.errorMessage,
      userAgent: metadata.userAgent,
      userId: metadata.userId,
      requestId: metadata.requestId,
      resourceUsage: this.getCurrentResourceUsage(),
      customMetrics: metadata.customMetrics
    };

    this.metrics.push(metric);

    // Manter apenas as últimas 10000 métricas
    if (this.metrics.length > 10000) {
      this.metrics = this.metrics.slice(-10000);
    }

    // Análise imediata para alertas críticos
    this.checkOperationThresholds(metric);
  }

  /**
   * Obter métricas de performance em tempo real
   */
  getRealTimeMetrics(timeRange: number = 300000): { // 5 minutos por padrão
    avgResponseTime: number;
    requestCount: number;
    errorRate: number;
    throughput: number;
    resourceUsage: {
      cpu: number;
      memory: number;
      disk: number;
      network: number;
    };
    topSlowOperations: Array<{
      service: string;
      operation: string;
      avgDuration: number;
      count: number;
    }>;
    errorBreakdown: Record<string, number>;
  } {
    const cutoffTime = new Date(Date.now() - timeRange);
    const recentMetrics = this.metrics.filter(m => m.timestamp >= cutoffTime);

    if (recentMetrics.length === 0) {
      return {
        avgResponseTime: 0,
        requestCount: 0,
        errorRate: 0,
        throughput: 0,
        resourceUsage: { cpu: 0, memory: 0, disk: 0, network: 0 },
        topSlowOperations: [],
        errorBreakdown: {}
      };
    }

    // Cálculos básicos
    const totalRequests = recentMetrics.length;
    const errorCount = recentMetrics.filter(m => !m.success).length;
    const avgResponseTime = recentMetrics.reduce((sum, m) => sum + m.duration, 0) / totalRequests;
    const errorRate = errorCount / totalRequests;
    const throughput = (totalRequests / (timeRange / 1000)) * 60; // req/min

    // Resource usage médio
    const avgResourceUsage = recentMetrics.reduce(
      (acc, m) => ({
        cpu: acc.cpu + m.resourceUsage.cpuUsage,
        memory: acc.memory + m.resourceUsage.memoryUsage,
        disk: acc.disk + m.resourceUsage.diskUsage,
        network: acc.network + m.resourceUsage.networkIO
      }),
      { cpu: 0, memory: 0, disk: 0, network: 0 }
    );

    Object.keys(avgResourceUsage).forEach(key => {
      (avgResourceUsage as any)[key] /= totalRequests;
    });

    // Top operações lentas
    const operationStats = new Map<string, { totalDuration: number; count: number }>();
    
    recentMetrics.forEach(m => {
      const key = `${m.service}:${m.operation}`;
      const existing = operationStats.get(key) || { totalDuration: 0, count: 0 };
      operationStats.set(key, {
        totalDuration: existing.totalDuration + m.duration,
        count: existing.count + 1
      });
    });

    const topSlowOperations = Array.from(operationStats.entries())
      .map(([key, stats]) => {
        const [service, operation] = key.split(':');
        return {
          service,
          operation,
          avgDuration: stats.totalDuration / stats.count,
          count: stats.count
        };
      })
      .sort((a, b) => b.avgDuration - a.avgDuration)
      .slice(0, 10);

    // Breakdown de erros
    const errorBreakdown: Record<string, number> = {};
    recentMetrics
      .filter(m => !m.success && m.errorMessage)
      .forEach(m => {
        const errorType = m.errorMessage!.split(':')[0] || 'Unknown';
        errorBreakdown[errorType] = (errorBreakdown[errorType] || 0) + 1;
      });

    return {
      avgResponseTime,
      requestCount: totalRequests,
      errorRate,
      throughput,
      resourceUsage: avgResourceUsage,
      topSlowOperations,
      errorBreakdown
    };
  }

  /**
   * Obter métricas históricas
   */
  getHistoricalMetrics(
    startTime: Date,
    endTime: Date,
    groupBy: 'minute' | 'hour' | 'day' = 'hour'
  ): Array<{
    timestamp: Date;
    avgResponseTime: number;
    requestCount: number;
    errorRate: number;
    resourceUsage: {
      cpu: number;
      memory: number;
      disk: number;
    };
  }> {
    const relevantMetrics = this.metrics.filter(
      m => m.timestamp >= startTime && m.timestamp <= endTime
    );

    if (relevantMetrics.length === 0) return [];

    // Agrupar métricas por intervalo de tempo
    const groupSize = groupBy === 'minute' ? 60000 : groupBy === 'hour' ? 3600000 : 86400000;
    const groups = new Map<number, APMMetrics[]>();

    relevantMetrics.forEach(metric => {
      const groupKey = Math.floor(metric.timestamp.getTime() / groupSize) * groupSize;
      const existing = groups.get(groupKey) || [];
      existing.push(metric);
      groups.set(groupKey, existing);
    });

    return Array.from(groups.entries())
      .map(([timestamp, metrics]) => {
        const errorCount = metrics.filter(m => !m.success).length;
        const avgResponseTime = metrics.reduce((sum, m) => sum + m.duration, 0) / metrics.length;
        const errorRate = errorCount / metrics.length;

        const avgResourceUsage = metrics.reduce(
          (acc, m) => ({
            cpu: acc.cpu + m.resourceUsage.cpuUsage,
            memory: acc.memory + m.resourceUsage.memoryUsage,
            disk: acc.disk + m.resourceUsage.diskUsage
          }),
          { cpu: 0, memory: 0, disk: 0 }
        );

        Object.keys(avgResourceUsage).forEach(key => {
          (avgResourceUsage as any)[key] /= metrics.length;
        });

        return {
          timestamp: new Date(timestamp),
          avgResponseTime,
          requestCount: metrics.length,
          errorRate,
          resourceUsage: avgResourceUsage
        };
      })
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  }

  /**
   * Obter alertas ativos
   */
  getActiveAlerts(): APMAlert[] {
    return this.alerts.filter(alert => !alert.resolved);
  }

  /**
   * Resolver alerta
   */
  resolveAlert(alertId: string): boolean {
    const alert = this.alerts.find(a => a.id === alertId);
    if (alert) {
      alert.resolved = true;
      return true;
    }
    return false;
  }

  /**
   * Configurar thresholds customizados
   */
  setThresholds(newThresholds: Partial<PerformanceThresholds>): void {
    this.thresholds = { ...this.thresholds, ...newThresholds };
  }

  /**
   * Coletar métricas do sistema
   */
  private collectSystemMetrics(): void {
    const resourceUsage = this.getCurrentResourceUsage();
    
    this.recordOperation(
      'system',
      'health-check',
      0,
      true,
      {
        resourceUsage,
        customMetrics: {
          uptime: process.uptime(),
          activeHandles: (process as any)._getActiveHandles().length,
          activeRequests: (process as any)._getActiveRequests().length
        }
      }
    );
  }

  /**
   * Analisar métricas e detectar anomalias
   */
  private analyzeMetrics(): void {
    const recentMetrics = this.getRealTimeMetrics(300000); // 5 minutos

    // Verificar response time
    if (recentMetrics.avgResponseTime > this.thresholds.responseTime.critical) {
      this.createAlert('performance', 'critical', 
        `Average response time is ${recentMetrics.avgResponseTime}ms (threshold: ${this.thresholds.responseTime.critical}ms)`,
        'system', 'response-time', { responseTime: recentMetrics.avgResponseTime });
    } else if (recentMetrics.avgResponseTime > this.thresholds.responseTime.warning) {
      this.createAlert('performance', 'warning',
        `Average response time is ${recentMetrics.avgResponseTime}ms (threshold: ${this.thresholds.responseTime.warning}ms)`,
        'system', 'response-time', { responseTime: recentMetrics.avgResponseTime });
    }

    // Verificar error rate
    if (recentMetrics.errorRate > this.thresholds.errorRate.critical) {
      this.createAlert('error', 'critical',
        `Error rate is ${(recentMetrics.errorRate * 100).toFixed(2)}% (threshold: ${this.thresholds.errorRate.critical * 100}%)`,
        'system', 'error-rate', { errorRate: recentMetrics.errorRate });
    }

    // Verificar resource usage
    if (recentMetrics.resourceUsage.cpu > this.thresholds.resourceUsage.cpu) {
      this.createAlert('resource', 'warning',
        `CPU usage is ${recentMetrics.resourceUsage.cpu.toFixed(1)}% (threshold: ${this.thresholds.resourceUsage.cpu}%)`,
        'system', 'cpu-usage', { cpuUsage: recentMetrics.resourceUsage.cpu });
    }

    // Verificar throughput
    if (recentMetrics.throughput < this.thresholds.throughput.minimum) {
      this.createAlert('availability', 'warning',
        `Throughput is ${recentMetrics.throughput.toFixed(1)} req/min (minimum: ${this.thresholds.throughput.minimum})`,
        'system', 'throughput', { throughput: recentMetrics.throughput });
    }
  }

  /**
   * Verificar thresholds para operação individual
   */
  private checkOperationThresholds(metric: APMMetrics): void {
    if (metric.duration > this.thresholds.responseTime.critical) {
      this.createAlert('performance', 'critical',
        `Operation ${metric.service}:${metric.operation} took ${metric.duration}ms`,
        metric.service, metric.operation, { duration: metric.duration });
    }

    if (!metric.success) {
      this.createAlert('error', 'warning',
        `Operation ${metric.service}:${metric.operation} failed: ${metric.errorMessage || 'Unknown error'}`,
        metric.service, metric.operation, { statusCode: metric.statusCode || 0 });
    }
  }

  /**
   * Verificar e processar alertas
   */
  private checkAlerts(): void {
    // Auto-resolver alertas antigos (mais de 1 hora)
    const oneHourAgo = new Date(Date.now() - 3600000);
    this.alerts.forEach(alert => {
      if (alert.timestamp < oneHourAgo && !alert.resolved) {
        alert.resolved = true;
      }
    });

    // Limitar número de alertas (manter últimos 1000)
    if (this.alerts.length > 1000) {
      this.alerts = this.alerts.slice(-1000);
    }
  }

  /**
   * Criar novo alerta
   */
  private createAlert(
    type: APMAlert['type'],
    severity: APMAlert['severity'],
    message: string,
    service: string,
    operation?: string,
    metrics: Record<string, number> = {}
  ): void {
    // Verificar se já existe alerta similar ativo
    const existingAlert = this.alerts.find(alert => 
      !alert.resolved &&
      alert.type === type &&
      alert.service === service &&
      alert.operation === operation &&
      alert.message === message
    );

    if (existingAlert) {
      // Atualizar timestamp do alerta existente
      existingAlert.timestamp = new Date();
      return;
    }

    const alert: APMAlert = {
      id: `alert_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      type,
      severity,
      message,
      timestamp: new Date(),
      service,
      operation,
      metrics,
      resolved: false
    };

    this.alerts.push(alert);

    // Log do alerta
    const logLevel = severity === 'critical' ? 'error' : severity === 'warning' ? 'warn' : 'info';
    console[logLevel](`APM Alert [${severity.toUpperCase()}]: ${message}`);
  }

  /**
   * Obter usage atual dos recursos
   */
  private getCurrentResourceUsage(): APMMetrics['resourceUsage'] {
    const memUsage = process.memoryUsage();
    const cpuUsage = process.cpuUsage();
    
    return {
      cpuUsage: ((cpuUsage.user + cpuUsage.system) / 1000000) * 100, // Conversão aproximada
      memoryUsage: (memUsage.heapUsed / memUsage.heapTotal) * 100,
      diskUsage: 0, // Seria necessário uma biblioteca externa para disk usage
      networkIO: 0  // Seria necessário uma biblioteca externa para network IO
    };
  }

  /**
   * Cleanup
   */
  destroy(): void {
    this.stopMonitoring();
  }
}

// Instância singleton
export const apmService = new APMService();

// Middleware para Express
export const apmMiddleware = (req: any, res: any, next: any) => {
  const startTime = Date.now();
  
  res.on('finish', () => {
    const duration = Date.now() - startTime;
    const success = res.statusCode < 400;
    
    apmService.recordOperation(
      'api',
      `${req.method} ${req.route?.path || req.path}`,
      duration,
      success,
      {
        statusCode: res.statusCode,
        errorMessage: !success ? `HTTP ${res.statusCode}` : undefined,
        userAgent: req.get('User-Agent'),
        userId: req.user?.id,
        requestId: req.requestId
      }
    );
  });

  next();
};