/**
 * Testes para Sistema de Observabilidade Completo
 * Foundation: Replit Cost Optimizer
 * Data: 28/01/2025
 */

import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest';
import { loggingService } from '../../src/observability/LoggingService';
import { apmService } from '../../src/apm/APMService';
import { DistributedTracingService } from '../../src/tracing/DistributedTracingService';

// Criar instância de tracing para testes com 100% sampling
const testTracingService = new DistributedTracingService({
  serviceName: 'test-service',
  samplingRate: 1.0, // 100% sampling para testes
  exportInterval: 60000
});

describe('Sistema de Observabilidade', () => {
  beforeEach(() => {
    // Reset dos serviços
    vi.clearAllMocks();
  });

  afterEach(() => {
    // Cleanup após cada teste
    apmService.stopMonitoring();
    testTracingService.destroy();
  });

  describe('CentralizedLoggingService', () => {
    it('deve registrar logs de informação', async () => {
      const consoleSpy = vi.spyOn(console, 'log').mockImplementation(() => {});
      
      await loggingService.info('Test message', {
        service: 'test-service',
        metadata: { testData: 'value' }
      });

      expect(consoleSpy).toHaveBeenCalledWith(
        expect.stringContaining('INFO')
      );
    });

    it('deve registrar logs de erro com stack trace', async () => {
      const consoleErrorSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      const testError = new Error('Test error');
      
      await loggingService.error('Error occurred', testError, {
        service: 'test-service'
      });

      expect(consoleErrorSpy).toHaveBeenCalledWith(testError.stack);
    });

    it('deve buscar logs por critério', async () => {
      // Adicionar alguns logs
      await loggingService.info('First log', { service: 'service-a' });
      await loggingService.warn('Second log', { service: 'service-b' });
      await loggingService.error('Third log', undefined, { service: 'service-a' });

      const results = await loggingService.searchLogs({
        service: 'service-a',
        limit: 10
      });

      expect(results.length).toBe(2);
      expect(results.every(log => log.service === 'service-a')).toBe(true);
    });
  });

  describe('APMService', () => {
    it('deve iniciar e parar monitoramento', () => {
      const consoleSpy = vi.spyOn(console, 'log').mockImplementation(() => {});
      
      apmService.startMonitoring();
      expect(consoleSpy).toHaveBeenCalledWith('APM Monitoring started');
      
      apmService.stopMonitoring();
      expect(consoleSpy).toHaveBeenCalledWith('APM Monitoring stopped');
    });

    it('deve registrar operações', () => {
      apmService.recordOperation('test-service', 'test-operation', 250, true, {
        statusCode: 200,
        userId: 'user123'
      });

      const metrics = apmService.getRealTimeMetrics(60000);
      expect(metrics.requestCount).toBeGreaterThan(0);
      expect(metrics.avgResponseTime).toBeGreaterThan(0);
    });

    it('deve detectar operações lentas', () => {
      const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
      
      // Simular operação lenta (acima do threshold crítico)
      apmService.recordOperation('test-service', 'slow-operation', 5000, true);

      expect(consoleSpy).toHaveBeenCalledWith(
        expect.stringContaining('APM Alert [CRITICAL]')
      );
    });
  });

  describe('DistributedTracingService', () => {
    it('deve criar trace básica', () => {
      const context = testTracingService.startTrace('test-operation');
      
      expect(context.traceId).toBeDefined();
      expect(context.spanId).toBeDefined();
      expect(context.sampled).toBe(true); // 100% sampling nos testes
    });

    it('deve criar span filho', () => {
      const parentContext = testTracingService.startTrace('parent-operation');
      const childContext = testTracingService.createChildSpan(parentContext, 'child-operation');
      
      expect(childContext.traceId).toBe(parentContext.traceId);
      expect(childContext.parentSpanId).toBe(parentContext.spanId);
      expect(childContext.spanId).not.toBe(parentContext.spanId);
    });

    it('deve adicionar tags ao span', () => {
      const context = testTracingService.startTrace('test-operation');
      
      testTracingService.setSpanTag(context, 'user.id', 'user123');
      testTracingService.setSpanTags(context, {
        'http.method': 'GET',
        'http.status': 200
      });

      const span = testTracingService.getSpan(context.spanId);
      expect(span?.tags['user.id']).toBe('user123');
      expect(span?.tags['http.method']).toBe('GET');
      expect(span?.tags['http.status']).toBe(200);
    });
  });

  describe('Integração dos Sistemas', () => {
    it('deve funcionar em conjunto - logging + APM + tracing', async () => {
      // Iniciar trace
      const traceContext = testTracingService.startTrace('integration-test');
      
      // Registrar operação no APM
      apmService.recordOperation('integration', 'test-operation', 150, true, {
        requestId: traceContext.spanId
      });
      
      // Log com contexto de trace
      await loggingService.info('Integration test executed', {
        service: 'integration',
        requestId: traceContext.spanId,
        metadata: {
          traceId: traceContext.traceId,
          operation: 'test-operation'
        }
      });
      
      // Finalizar trace
      testTracingService.addSpanLog(traceContext, 'info', 'Operation completed successfully');
      testTracingService.finishSpan(traceContext);
      
      // Verificar se dados estão correlacionados
      const logs = await loggingService.searchLogs({
        search: traceContext.spanId,
        limit: 10
      });
      
      const apmMetrics = apmService.getRealTimeMetrics(60000);
      const span = testTracingService.getSpan(traceContext.spanId);
      
      expect(logs.length).toBeGreaterThan(0);
      expect(apmMetrics.requestCount).toBeGreaterThan(0);
      expect(span?.status).toBe('ok');
    });
  });
});