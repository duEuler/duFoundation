/**
 * Distributed Tracing Service
 * Foundation: Replit Cost Optimizer
 * Data: 28/01/2025
 */

export interface TraceSpan {
  traceId: string;
  spanId: string;
  parentSpanId?: string;
  operationName: string;
  service: string;
  startTime: Date;
  endTime?: Date;
  duration?: number;
  status: 'ok' | 'error' | 'timeout';
  tags: Record<string, string | number | boolean>;
  logs: Array<{
    timestamp: Date;
    level: 'info' | 'warn' | 'error';
    message: string;
    fields?: Record<string, any>;
  }>;
  baggage: Record<string, string>;
}

export interface TraceContext {
  traceId: string;
  spanId: string;
  parentSpanId?: string;
  baggage: Record<string, string>;
  sampled: boolean;
}

export interface TracingConfiguration {
  serviceName: string;
  samplingRate: number;
  maxSpansPerTrace: number;
  exportInterval: number;
  jaegerEndpoint?: string;
  zipkinEndpoint?: string;
}

export class DistributedTracingService {
  private spans: Map<string, TraceSpan> = new Map();
  private activeTraces: Map<string, TraceSpan[]> = new Map();
  private config: TracingConfiguration;
  private exportInterval: NodeJS.Timeout;

  constructor(config: Partial<TracingConfiguration> = {}) {
    this.config = {
      serviceName: 'replit-optimizer',
      samplingRate: 0.1, // 10% das traces
      maxSpansPerTrace: 100,
      exportInterval: 30000, // 30 segundos
      ...config
    };

    this.startExportInterval();
  }

  /**
   * Iniciar uma nova trace
   */
  startTrace(operationName: string, parentContext?: TraceContext): TraceContext {
    const traceId = parentContext?.traceId || this.generateTraceId();
    const spanId = this.generateSpanId();
    const sampled = parentContext?.sampled !== undefined ? parentContext.sampled : Math.random() < this.config.samplingRate;

    const context: TraceContext = {
      traceId,
      spanId,
      parentSpanId: parentContext?.spanId,
      baggage: parentContext?.baggage ? { ...parentContext.baggage } : {},
      sampled
    };

    if (sampled) {
      const span: TraceSpan = {
        traceId,
        spanId,
        parentSpanId: parentContext?.spanId,
        operationName,
        service: this.config.serviceName,
        startTime: new Date(),
        status: 'ok',
        tags: {},
        logs: [],
        baggage: context.baggage
      };

      this.spans.set(spanId, span);
      
      // Adicionar à trace ativa
      const traceSpans = this.activeTraces.get(traceId) || [];
      traceSpans.push(span);
      this.activeTraces.set(traceId, traceSpans);
    }

    return context;
  }

  /**
   * Finalizar um span
   */
  finishSpan(context: TraceContext, status: TraceSpan['status'] = 'ok'): void {
    if (!context.sampled) return;

    const span = this.spans.get(context.spanId);
    if (span) {
      span.endTime = new Date();
      span.duration = span.endTime.getTime() - span.startTime.getTime();
      span.status = status;

      // Log automático para spans com erro
      if (status === 'error') {
        this.addSpanLog(context, 'error', 'Span finished with error status');
      }
    }
  }

  /**
   * Adicionar tag ao span
   */
  setSpanTag(context: TraceContext, key: string, value: string | number | boolean): void {
    if (!context.sampled) return;

    const span = this.spans.get(context.spanId);
    if (span) {
      span.tags[key] = value;
    }
  }

  /**
   * Adicionar múltiplas tags
   */
  setSpanTags(context: TraceContext, tags: Record<string, string | number | boolean>): void {
    if (!context.sampled) return;

    const span = this.spans.get(context.spanId);
    if (span) {
      Object.assign(span.tags, tags);
    }
  }

  /**
   * Adicionar log ao span
   */
  addSpanLog(
    context: TraceContext, 
    level: 'info' | 'warn' | 'error', 
    message: string, 
    fields?: Record<string, any>
  ): void {
    if (!context.sampled) return;

    const span = this.spans.get(context.spanId);
    if (span) {
      span.logs.push({
        timestamp: new Date(),
        level,
        message,
        fields
      });
    }
  }

  /**
   * Adicionar baggage (dados que passam entre spans)
   */
  setBaggage(context: TraceContext, key: string, value: string): TraceContext {
    return {
      ...context,
      baggage: {
        ...context.baggage,
        [key]: value
      }
    };
  }

  /**
   * Obter baggage
   */
  getBaggage(context: TraceContext, key: string): string | undefined {
    return context.baggage[key];
  }

  /**
   * Criar span filho
   */
  createChildSpan(parentContext: TraceContext, operationName: string): TraceContext {
    return this.startTrace(operationName, parentContext);
  }

  /**
   * Wrapper para funções com tracing automático
   */
  async traceFunction<T>(
    operationName: string,
    fn: (context: TraceContext) => Promise<T>,
    parentContext?: TraceContext
  ): Promise<T> {
    const context = this.startTrace(operationName, parentContext);
    
    try {
      const result = await fn(context);
      this.finishSpan(context, 'ok');
      return result;
    } catch (error) {
      this.setSpanTag(context, 'error', true);
      this.setSpanTag(context, 'error.message', (error as Error).message);
      this.addSpanLog(context, 'error', (error as Error).message, {
        stack: (error as Error).stack
      });
      this.finishSpan(context, 'error');
      throw error;
    }
  }

  /**
   * Obter trace completa
   */
  getTrace(traceId: string): TraceSpan[] | undefined {
    return this.activeTraces.get(traceId);
  }

  /**
   * Obter span por ID
   */
  getSpan(spanId: string): TraceSpan | undefined {
    return this.spans.get(spanId);
  }

  /**
   * Buscar traces por critério
   */
  searchTraces(criteria: {
    service?: string;
    operation?: string;
    tag?: { key: string; value: any };
    minDuration?: number;
    maxDuration?: number;
    status?: TraceSpan['status'];
    startTime?: Date;
    endTime?: Date;
    limit?: number;
  }): TraceSpan[] {
    let results: TraceSpan[] = Array.from(this.spans.values());

    if (criteria.service) {
      results = results.filter(span => span.service === criteria.service);
    }

    if (criteria.operation) {
      results = results.filter(span => span.operationName.includes(criteria.operation!));
    }

    if (criteria.tag) {
      results = results.filter(span => 
        span.tags[criteria.tag!.key] === criteria.tag!.value
      );
    }

    if (criteria.minDuration !== undefined) {
      results = results.filter(span => 
        span.duration !== undefined && span.duration >= criteria.minDuration!
      );
    }

    if (criteria.maxDuration !== undefined) {
      results = results.filter(span => 
        span.duration !== undefined && span.duration <= criteria.maxDuration!
      );
    }

    if (criteria.status) {
      results = results.filter(span => span.status === criteria.status);
    }

    if (criteria.startTime) {
      results = results.filter(span => span.startTime >= criteria.startTime!);
    }

    if (criteria.endTime) {
      results = results.filter(span => span.startTime <= criteria.endTime!);
    }

    return results
      .sort((a, b) => b.startTime.getTime() - a.startTime.getTime())
      .slice(0, criteria.limit || 100);
  }

  /**
   * Obter estatísticas de tracing
   */
  getTracingStatistics(): {
    totalTraces: number;
    totalSpans: number;
    avgTraceLength: number;
    errorRate: number;
    slowestOperations: Array<{
      operation: string;
      service: string;
      avgDuration: number;
      count: number;
    }>;
    serviceBreakdown: Record<string, number>;
  } {
    const allSpans = Array.from(this.spans.values());
    const traces = Array.from(this.activeTraces.values());

    const errorSpans = allSpans.filter(span => span.status === 'error');
    const errorRate = allSpans.length > 0 ? errorSpans.length / allSpans.length : 0;

    const avgTraceLength = traces.length > 0 
      ? traces.reduce((sum, trace) => sum + trace.length, 0) / traces.length 
      : 0;

    // Operações mais lentas
    const operationStats = new Map<string, { totalDuration: number; count: number }>();
    
    allSpans
      .filter(span => span.duration !== undefined)
      .forEach(span => {
        const key = `${span.service}:${span.operationName}`;
        const existing = operationStats.get(key) || { totalDuration: 0, count: 0 };
        operationStats.set(key, {
          totalDuration: existing.totalDuration + span.duration!,
          count: existing.count + 1
        });
      });

    const slowestOperations = Array.from(operationStats.entries())
      .map(([key, stats]) => {
        const [service, operation] = key.split(':');
        return {
          operation,
          service,
          avgDuration: stats.totalDuration / stats.count,
          count: stats.count
        };
      })
      .sort((a, b) => b.avgDuration - a.avgDuration)
      .slice(0, 10);

    // Breakdown por serviço
    const serviceBreakdown: Record<string, number> = {};
    allSpans.forEach(span => {
      serviceBreakdown[span.service] = (serviceBreakdown[span.service] || 0) + 1;
    });

    return {
      totalTraces: traces.length,
      totalSpans: allSpans.length,
      avgTraceLength,
      errorRate,
      slowestOperations,
      serviceBreakdown
    };
  }

  /**
   * Exportar traces para sistema externo
   */
  async exportTraces(): Promise<void> {
    const completedTraces = Array.from(this.activeTraces.entries())
      .filter(([_, spans]) => spans.every(span => span.endTime !== undefined))
      .map(([traceId, spans]) => ({ traceId, spans }));

    if (completedTraces.length === 0) return;

    try {
      // Simular export para Jaeger/Zipkin
      if (this.config.jaegerEndpoint) {
        await this.exportToJaeger(completedTraces);
      }

      if (this.config.zipkinEndpoint) {
        await this.exportToZipkin(completedTraces);
      }

      // Em desenvolvimento, salvar em arquivo
      if (process.env.NODE_ENV === 'development') {
        await this.saveTracesToFile(completedTraces);
      }

      // Remover traces exportadas
      completedTraces.forEach(({ traceId, spans }) => {
        this.activeTraces.delete(traceId);
        spans.forEach(span => this.spans.delete(span.spanId));
      });

    } catch (error) {
      console.error('Failed to export traces:', error);
    }
  }

  /**
   * Limpar traces antigas
   */
  cleanup(): void {
    const oneHourAgo = new Date(Date.now() - 3600000);
    
    // Remover spans antigos
    Array.from(this.spans.entries()).forEach(([spanId, span]) => {
      if (span.startTime < oneHourAgo) {
        this.spans.delete(spanId);
      }
    });

    // Remover traces antigas
    Array.from(this.activeTraces.entries()).forEach(([traceId, spans]) => {
      const recentSpans = spans.filter(span => span.startTime >= oneHourAgo);
      if (recentSpans.length === 0) {
        this.activeTraces.delete(traceId);
      } else if (recentSpans.length !== spans.length) {
        this.activeTraces.set(traceId, recentSpans);
      }
    });
  }

  /**
   * Serializar contexto para headers HTTP
   */
  serializeContext(context: TraceContext): string {
    return JSON.stringify({
      traceId: context.traceId,
      spanId: context.spanId,
      parentSpanId: context.parentSpanId,
      baggage: context.baggage,
      sampled: context.sampled
    });
  }

  /**
   * Deserializar contexto de headers HTTP
   */
  deserializeContext(serialized: string): TraceContext | null {
    try {
      return JSON.parse(serialized);
    } catch {
      return null;
    }
  }

  private startExportInterval(): void {
    this.exportInterval = setInterval(() => {
      this.exportTraces();
      this.cleanup();
    }, this.config.exportInterval);
  }

  private generateTraceId(): string {
    return Math.random().toString(36).substr(2, 16);
  }

  private generateSpanId(): string {
    return Math.random().toString(36).substr(2, 8);
  }

  private async exportToJaeger(traces: Array<{ traceId: string; spans: TraceSpan[] }>): Promise<void> {
    // Implementação simplificada - na prática usaria o SDK do Jaeger
    console.log(`Exporting ${traces.length} traces to Jaeger`);
  }

  private async exportToZipkin(traces: Array<{ traceId: string; spans: TraceSpan[] }>): Promise<void> {
    // Implementação simplificada - na prática usaria o SDK do Zipkin
    console.log(`Exporting ${traces.length} traces to Zipkin`);
  }

  private async saveTracesToFile(traces: Array<{ traceId: string; spans: TraceSpan[] }>): Promise<void> {
    try {
      const fs = require('fs').promises;
      const tracesData = traces.map(trace => JSON.stringify(trace)).join('\n') + '\n';
      
      await fs.appendFile('logs/traces.log', tracesData).catch(async () => {
        require('fs').mkdirSync('logs', { recursive: true });
        return await fs.appendFile('logs/traces.log', tracesData);
      });
    } catch (error) {
      console.error('Failed to save traces to file:', error);
    }
  }

  /**
   * Cleanup
   */
  destroy(): void {
    if (this.exportInterval) {
      clearInterval(this.exportInterval);
    }
    this.exportTraces();
  }
}

// Instância singleton
export const tracingService = new DistributedTracingService();

// Middleware para Express
export const tracingMiddleware = (req: any, res: any, next: any) => {
  // Extrair contexto dos headers
  const traceHeader = req.headers['x-trace-context'];
  const parentContext = traceHeader 
    ? tracingService.deserializeContext(traceHeader)
    : undefined;

  // Iniciar span para a requisição
  const context = tracingService.startTrace(
    `${req.method} ${req.route?.path || req.path}`,
    parentContext || undefined
  );

  // Adicionar tags
  tracingService.setSpanTags(context, {
    'http.method': req.method,
    'http.url': req.originalUrl,
    'http.user_agent': req.get('User-Agent') || '',
    'user.id': req.user?.id || '',
    'request.id': req.requestId || ''
  });

  // Adicionar contexto à requisição
  req.traceContext = context;

  // Hook no response
  res.on('finish', () => {
    tracingService.setSpanTag(context, 'http.status_code', res.statusCode);
    
    const status = res.statusCode >= 400 ? 'error' : 'ok';
    tracingService.finishSpan(context, status);
  });

  // Adicionar header de resposta para propagação
  res.setHeader('x-trace-context', tracingService.serializeContext(context));

  next();
};