# src/ml/ModelTraining.py
import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import joblib
import logging
import json
from datetime import datetime, timedelta
import psycopg2
import redis
import os

class ModelTraining:
    def __init__(self, db_config, redis_config):
        self.db_config = db_config
        self.redis_client = redis.Redis(**redis_config)
        self.models = {}
        self.scalers = {}
        self.label_encoders = {}
        self.training_history = []
        
        # Setup logging
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
        
        # Feature columns for cost prediction
        self.feature_columns = [
            'file_count', 'total_size_mb', 'js_files', 'css_files', 'image_files',
            'complexity_score', 'dependency_count', 'hour_of_day', 'day_of_week',
            'user_activity_level', 'project_age_days', 'optimization_history_count',
            'average_file_size', 'code_density', 'external_api_calls',
            'cache_hit_ratio', 'previous_cost_avg', 'operation_type_encoded'
        ]
    
    def collect_training_data(self, days_back=30):
        """Collect historical data for model training"""
        try:
            conn = psycopg2.connect(**self.db_config)
            
            # Query to collect historical optimization data
            query = """
            SELECT 
                o.id,
                o.cost_before,
                o.cost_after,
                o.savings,
                o.file_count,
                o.total_size,
                o.complexity_score,
                o.created_at,
                o.operation_type,
                u.activity_level,
                p.file_types,
                p.dependencies,
                p.cache_settings
            FROM optimizations o
            JOIN users u ON o.user_id = u.id
            LEFT JOIN projects p ON o.project_id = p.id
            WHERE o.created_at >= %s
            AND o.cost_after IS NOT NULL
            ORDER BY o.created_at DESC
            """
            
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days_back)
            
            df = pd.read_sql_query(query, conn, params=[start_date])
            conn.close()
            
            if df.empty:
                self.logger.warning("No training data found")
                return None
            
            # Feature engineering
            df = self.engineer_features(df)
            
            self.logger.info(f"Collected {len(df)} training samples")
            return df
            
        except Exception as e:
            self.logger.error(f"Error collecting training data: {str(e)}")
            return None
    
    def engineer_features(self, df):
        """Engineer features for model training"""
        # Basic calculations
        df['total_size_mb'] = df['total_size'] / (1024 * 1024)
        df['actual_cost'] = df['cost_before']
        df['savings_achieved'] = df['savings']
        
        # Time-based features
        df['hour_of_day'] = pd.to_datetime(df['created_at']).dt.hour
        df['day_of_week'] = pd.to_datetime(df['created_at']).dt.dayofweek
        df['project_age_days'] = (datetime.now() - pd.to_datetime(df['created_at'])).dt.days
        
        # File type analysis
        df['js_files'] = df['file_types'].apply(lambda x: self.count_file_type(x, ['.js', '.ts', '.jsx', '.tsx']))
        df['css_files'] = df['file_types'].apply(lambda x: self.count_file_type(x, ['.css', '.scss', '.sass']))
        df['image_files'] = df['file_types'].apply(lambda x: self.count_file_type(x, ['.png', '.jpg', '.jpeg', '.gif']))
        
        # Derived features
        df['average_file_size'] = df['total_size'] / df['file_count'].replace(0, 1)
        df['code_density'] = df['complexity_score'] / df['file_count'].replace(0, 1)
        df['dependency_count'] = df['dependencies'].apply(lambda x: len(json.loads(x) if x else []))
        
        # External features (can be enhanced with real data)
        df['external_api_calls'] = np.random.randint(0, 50, len(df))  # Placeholder
        df['cache_hit_ratio'] = np.random.uniform(0.5, 0.95, len(df))  # Placeholder
        df['previous_cost_avg'] = df.groupby('id')['actual_cost'].transform('mean')
        df['optimization_history_count'] = df.groupby('id').cumcount()
        
        # Encode categorical variables
        if 'operation_type' in df.columns:
            le = LabelEncoder()
            df['operation_type_encoded'] = le.fit_transform(df['operation_type'].fillna('unknown'))
            self.label_encoders['operation_type'] = le
        else:
            df['operation_type_encoded'] = 0
        
        # Fill missing values
        df = df.fillna(df.mean(numeric_only=True))
        
        return df
    
    def count_file_type(self, file_types_json, extensions):
        """Count files of specific extensions"""
        try:
            if not file_types_json:
                return 0
            file_types = json.loads(file_types_json)
            return sum(1 for ext in extensions if ext in file_types)
        except:
            return 0
    
    def train_cost_prediction_model(self, data, model_type='random_forest'):
        """Train cost prediction model"""
        if data is None or data.empty:
            self.logger.error("No data available for training")
            return None
        
        try:
            # Prepare features and target
            X = data[self.feature_columns]
            y = data['actual_cost']
            
            # Handle missing columns
            for col in self.feature_columns:
                if col not in X.columns:
                    X[col] = 0
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(
                X, y, test_size=0.2, random_state=42
            )
            
            # Scale features
            scaler = StandardScaler()
            X_train_scaled = scaler.fit_transform(X_train)
            X_test_scaled = scaler.transform(X_test)
            
            # Initialize model
            if model_type == 'random_forest':
                model = RandomForestRegressor(
                    n_estimators=100,
                    max_depth=15,
                    min_samples_split=5,
                    random_state=42,
                    n_jobs=-1
                )
                param_grid = {
                    'n_estimators': [50, 100, 200],
                    'max_depth': [10, 15, 20],
                    'min_samples_split': [2, 5, 10]
                }
            else:
                model = GradientBoostingRegressor(
                    n_estimators=100,
                    learning_rate=0.1,
                    max_depth=6,
                    random_state=42
                )
                param_grid = {
                    'n_estimators': [50, 100, 200],
                    'learning_rate': [0.05, 0.1, 0.2],
                    'max_depth': [4, 6, 8]
                }
            
            # Hyperparameter tuning
            grid_search = GridSearchCV(
                model, param_grid, cv=5, scoring='neg_mean_absolute_error', n_jobs=-1
            )
            
            grid_search.fit(X_train_scaled, y_train)
            best_model = grid_search.best_estimator_
            
            # Evaluate model
            train_pred = best_model.predict(X_train_scaled)
            test_pred = best_model.predict(X_test_scaled)
            
            metrics = {
                'train_mae': mean_absolute_error(y_train, train_pred),
                'test_mae': mean_absolute_error(y_test, test_pred),
                'train_rmse': np.sqrt(mean_squared_error(y_train, train_pred)),
                'test_rmse': np.sqrt(mean_squared_error(y_test, test_pred)),
                'train_r2': r2_score(y_train, train_pred),
                'test_r2': r2_score(y_test, test_pred),
                'cv_score': cross_val_score(best_model, X_train_scaled, y_train, cv=5).mean()
            }
            
            # Store model and scaler
            self.models[f'cost_prediction_{model_type}'] = best_model
            self.scalers[f'cost_prediction_{model_type}'] = scaler
            
            # Save to disk
            model_path = f"models/cost_prediction_{model_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.joblib"
            scaler_path = f"models/scaler_{model_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.joblib"
            
            os.makedirs('models', exist_ok=True)
            joblib.dump(best_model, model_path)
            joblib.dump(scaler, scaler_path)
            
            # Store training results
            training_result = {
                'timestamp': datetime.now().isoformat(),
                'model_type': model_type,
                'model_path': model_path,
                'scaler_path': scaler_path,
                'metrics': metrics,
                'best_params': grid_search.best_params_,
                'feature_importance': dict(zip(self.feature_columns, best_model.feature_importances_)),
                'training_samples': len(X_train),
                'test_samples': len(X_test)
            }
            
            self.training_history.append(training_result)
            
            # Cache results in Redis
            self.redis_client.setex(
                f"model_training_result_{model_type}",
                86400,  # 24 hours
                json.dumps(training_result, default=str)
            )
            
            self.logger.info(f"Model trained successfully. Test MAE: {metrics['test_mae']:.4f}, Test R²: {metrics['test_r2']:.4f}")
            
            return training_result
            
        except Exception as e:
            self.logger.error(f"Error training model: {str(e)}")
            return None
    
    def train_optimization_efficiency_model(self, data):
        """Train model to predict optimization efficiency"""
        try:
            # Features for efficiency prediction
            efficiency_features = [
                'file_count', 'total_size_mb', 'complexity_score',
                'js_files', 'css_files', 'image_files',
                'dependency_count', 'cache_hit_ratio'
            ]
            
            # Calculate efficiency target
            data['efficiency'] = data['savings_achieved'] / data['actual_cost'].replace(0, 0.01)
            data['efficiency'] = data['efficiency'].clip(0, 1)  # Cap at 100%
            
            X = data[efficiency_features]
            y = data['efficiency']
            
            # Handle missing columns
            for col in efficiency_features:
                if col not in X.columns:
                    X[col] = 0
            
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
            
            # Train Random Forest for efficiency prediction
            model = RandomForestRegressor(n_estimators=100, random_state=42)
            model.fit(X_train, y_train)
            
            # Evaluate
            test_pred = model.predict(X_test)
            metrics = {
                'mae': mean_absolute_error(y_test, test_pred),
                'rmse': np.sqrt(mean_squared_error(y_test, test_pred)),
                'r2': r2_score(y_test, test_pred)
            }
            
            # Save model
            model_path = f"models/efficiency_prediction_{datetime.now().strftime('%Y%m%d_%H%M%S')}.joblib"
            joblib.dump(model, model_path)
            
            self.models['efficiency_prediction'] = model
            
            result = {
                'model_type': 'efficiency_prediction',
                'model_path': model_path,
                'metrics': metrics,
                'feature_importance': dict(zip(efficiency_features, model.feature_importances_)),
                'timestamp': datetime.now().isoformat()
            }
            
            self.logger.info(f"Efficiency model trained. Test R²: {metrics['r2']:.4f}")
            return result
            
        except Exception as e:
            self.logger.error(f"Error training efficiency model: {str(e)}")
            return None
    
    def run_full_training_pipeline(self):
        """Run complete model training pipeline"""
        self.logger.info("Starting full model training pipeline")
        
        # Collect training data
        data = self.collect_training_data(days_back=90)  # 3 months of data
        
        if data is None:
            self.logger.error("No training data available")
            return None
        
        results = {}
        
        # Train cost prediction models
        for model_type in ['random_forest', 'gradient_boost']:
            self.logger.info(f"Training {model_type} model")
            result = self.train_cost_prediction_model(data, model_type)
            if result:
                results[f'cost_prediction_{model_type}'] = result
        
        # Train efficiency prediction model
        self.logger.info("Training efficiency prediction model")
        efficiency_result = self.train_optimization_efficiency_model(data)
        if efficiency_result:
            results['efficiency_prediction'] = efficiency_result
        
        # Save complete training report
        training_report = {
            'pipeline_timestamp': datetime.now().isoformat(),
            'data_samples': len(data),
            'models_trained': list(results.keys()),
            'results': results,
            'data_quality': {
                'missing_values': data.isnull().sum().to_dict(),
                'data_ranges': {
                    'cost_min': float(data['actual_cost'].min()),
                    'cost_max': float(data['actual_cost'].max()),
                    'cost_mean': float(data['actual_cost'].mean())
                }
            }
        }
        
        # Save report
        report_path = f"models/training_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(report_path, 'w') as f:
            json.dump(training_report, f, indent=2)
        
        # Cache in Redis
        self.redis_client.setex(
            "latest_training_report",
            86400 * 7,  # 1 week
            json.dumps(training_report, default=str)
        )
        
        self.logger.info(f"Training pipeline completed. Report saved to {report_path}")
        return training_report

if __name__ == "__main__":
    # Configuration
    db_config = {
        'host': os.getenv('DB_HOST', 'localhost'),
        'port': os.getenv('DB_PORT', 5432),
        'database': os.getenv('DB_NAME', 'replit_optimizer'),
        'user': os.getenv('DB_USER', 'postgres'),
        'password': os.getenv('DB_PASSWORD', 'postgres')
    }
    
    redis_config = {
        'host': os.getenv('REDIS_HOST', 'localhost'),
        'port': os.getenv('REDIS_PORT', 6379),
        'decode_responses': True
    }
    
    # Run training
    trainer = ModelTraining(db_config, redis_config)
    report = trainer.run_full_training_pipeline()
    
    if report:
        print("Training completed successfully!")
        print(f"Models trained: {len(report['models_trained'])}")
        for model_name in report['models_trained']:
            metrics = report['results'][model_name]['metrics']
            print(f"{model_name}: R² = {metrics.get('test_r2', metrics.get('r2', 'N/A')):.4f}")
    else:
        print("Training failed!")