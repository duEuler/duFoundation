#!/bin/bash

# Script de Teste Completo do Sistema
# Testa todas as funcionalidades principais da plataforma

API_BASE="http://localhost:5000"

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Função para log com cores
log_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

log_error() {
    echo -e "${RED}✗ $1${NC}"
}

log_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

log_info() {
    echo -e "${BLUE}ℹ $1${NC}"
}

log_section() {
    echo -e "\n${CYAN}============================================================${NC}"
    echo -e "${CYAN}  $1${NC}"
    echo -e "${CYAN}============================================================${NC}"
}

# Contadores
PASSED=0
FAILED=0
WARNINGS=0

# Função para fazer requisições HTTP
make_request() {
    local method=$1
    local endpoint=$2
    local data=$3
    local headers=$4
    
    if [ "$method" = "GET" ]; then
        if [ -n "$headers" ]; then
            curl -s -w "HTTPSTATUS:%{http_code}" -H "$headers" "$API_BASE$endpoint"
        else
            curl -s -w "HTTPSTATUS:%{http_code}" "$API_BASE$endpoint"
        fi
    else
        if [ -n "$headers" ]; then
            curl -s -w "HTTPSTATUS:%{http_code}" -X "$method" -H "Content-Type: application/json" -H "$headers" -d "$data" "$API_BASE$endpoint"
        else
            curl -s -w "HTTPSTATUS:%{http_code}" -X "$method" -H "Content-Type: application/json" -d "$data" "$API_BASE$endpoint"
        fi
    fi
}

# Extrair status HTTP da resposta
extract_status() {
    echo "$1" | grep -o "HTTPSTATUS:[0-9]*" | cut -d: -f2
}

# Extrair body da resposta
extract_body() {
    echo "$1" | sed 's/HTTPSTATUS:[0-9]*$//'
}

# Variáveis globais para testes
AUTH_TOKEN=""
RESET_TOKEN=""
TEST_EMAIL="teste@marketplace.com"
TEST_PASSWORD="senha123"

# Teste 1: Autenticação
test_authentication() {
    log_section "TESTES DE AUTENTICAÇÃO"
    
    # Teste de registro
    log_info "Testando registro de usuário..."
    local register_data='{"email":"'$TEST_EMAIL'","password":"'$TEST_PASSWORD'","name":"Usuário Teste","userType":"customer"}'
    local register_response=$(make_request "POST" "/api/auth/register" "$register_data")
    local register_status=$(extract_status "$register_response")
    
    if [ "$register_status" = "200" ] || [ "$register_status" = "201" ]; then
        log_success "Registro realizado com sucesso"
        AUTH_TOKEN=$(extract_body "$register_response" | grep -o '"token":"[^"]*"' | cut -d'"' -f4)
        ((PASSED++))
    else
        log_warning "Registro falhou (pode ser usuário existente): Status $register_status"
        ((WARNINGS++))
    fi
    
    # Teste de login
    log_info "Testando login..."
    local login_data='{"email":"'$TEST_EMAIL'","password":"'$TEST_PASSWORD'"}'
    local login_response=$(make_request "POST" "/api/auth/login" "$login_data")
    local login_status=$(extract_status "$login_response")
    
    if [ "$login_status" = "200" ]; then
        log_success "Login realizado com sucesso"
        AUTH_TOKEN=$(extract_body "$login_response" | grep -o '"token":"[^"]*"' | cut -d'"' -f4)
        ((PASSED++))
    else
        log_error "Login falhou: Status $login_status"
        ((FAILED++))
        return 1
    fi
    
    return 0
}

# Teste 2: Recuperação de Senha
test_password_recovery() {
    log_section "TESTES DE RECUPERAÇÃO DE SENHA"
    
    # Teste de solicitação de reset
    log_info "Testando solicitação de recuperação de senha..."
    local forgot_data='{"email":"'$TEST_EMAIL'"}'
    local forgot_response=$(make_request "POST" "/api/auth/forgot-password" "$forgot_data")
    local forgot_status=$(extract_status "$forgot_response")
    
    if [ "$forgot_status" = "200" ]; then
        log_success "Solicitação de recuperação enviada com sucesso"
        RESET_TOKEN=$(extract_body "$forgot_response" | grep -o '"resetToken":"[^"]*"' | cut -d'"' -f4)
        log_info "Token gerado: ${RESET_TOKEN:0:20}..."
        ((PASSED++))
    else
        log_error "Recuperação falhou: Status $forgot_status"
        ((FAILED++))
        return 1
    fi
    
    # Teste de verificação de token
    if [ -n "$RESET_TOKEN" ]; then
        log_info "Testando verificação de token..."
        local verify_response=$(make_request "GET" "/api/auth/verify-reset-token/$RESET_TOKEN")
        local verify_status=$(extract_status "$verify_response")
        
        if [ "$verify_status" = "200" ]; then
            log_success "Token válido"
            ((PASSED++))
        else
            log_error "Token inválido: Status $verify_status"
            ((FAILED++))
            return 1
        fi
    fi
    
    # Teste de reset de senha
    if [ -n "$RESET_TOKEN" ]; then
        log_info "Testando redefinição de senha..."
        local new_password="novaSenha123"
        local reset_data='{"token":"'$RESET_TOKEN'","newPassword":"'$new_password'"}'
        local reset_response=$(make_request "POST" "/api/auth/reset-password" "$reset_data")
        local reset_status=$(extract_status "$reset_response")
        
        if [ "$reset_status" = "200" ]; then
            log_success "Senha redefinida com sucesso"
            ((PASSED++))
            
            # Teste de login com nova senha
            log_info "Testando login com nova senha..."
            local new_login_data='{"email":"'$TEST_EMAIL'","password":"'$new_password'"}'
            local new_login_response=$(make_request "POST" "/api/auth/login" "$new_login_data")
            local new_login_status=$(extract_status "$new_login_response")
            
            if [ "$new_login_status" = "200" ]; then
                log_success "Login com nova senha funcionou"
                AUTH_TOKEN=$(extract_body "$new_login_response" | grep -o '"token":"[^"]*"' | cut -d'"' -f4)
                ((PASSED++))
                
                # Restaurar senha original
                log_info "Restaurando senha original..."
                local restore_forgot=$(make_request "POST" "/api/auth/forgot-password" "$forgot_data")
                local new_reset_token=$(extract_body "$restore_forgot" | grep -o '"resetToken":"[^"]*"' | cut -d'"' -f4)
                local restore_data='{"token":"'$new_reset_token'","newPassword":"'$TEST_PASSWORD'"}'
                make_request "POST" "/api/auth/reset-password" "$restore_data" > /dev/null
                log_success "Senha original restaurada"
            else
                log_error "Login com nova senha falhou: Status $new_login_status"
                ((FAILED++))
            fi
        else
            log_error "Reset de senha falhou: Status $reset_status"
            ((FAILED++))
            return 1
        fi
    fi
    
    return 0
}

# Teste 3: Marketplace
test_marketplace() {
    log_section "TESTES DE MARKETPLACE"
    
    # Teste de listagem de produtos
    log_info "Testando listagem de produtos..."
    local products_response=$(make_request "GET" "/api/marketplace/products")
    local products_status=$(extract_status "$products_response")
    
    if [ "$products_status" = "200" ]; then
        local product_count=$(extract_body "$products_response" | grep -o '"id"' | wc -l)
        log_success "$product_count produtos encontrados"
        ((PASSED++))
    else
        log_error "Falha ao listar produtos: Status $products_status"
        ((FAILED++))
        return 1
    fi
    
    # Teste de categorias
    log_info "Testando listagem de categorias..."
    local categories_response=$(make_request "GET" "/api/marketplace/categories")
    local categories_status=$(extract_status "$categories_response")
    
    if [ "$categories_status" = "200" ]; then
        log_success "Categorias carregadas com sucesso"
        ((PASSED++))
    else
        log_warning "Falha ao listar categorias: Status $categories_status"
        ((WARNINGS++))
    fi
    
    return 0
}

# Teste 4: Downloads (com autenticação)
test_downloads() {
    log_section "TESTES DE DOWNLOADS"
    
    if [ -z "$AUTH_TOKEN" ]; then
        log_error "Token de autenticação necessário para testes de downloads"
        ((FAILED++))
        return 1
    fi
    
    local auth_header="Authorization: Bearer $AUTH_TOKEN"
    
    # Teste de biblioteca do usuário
    log_info "Testando biblioteca do usuário..."
    local library_response=$(make_request "GET" "/api/downloads/my-library" "" "$auth_header")
    local library_status=$(extract_status "$library_response")
    
    if [ "$library_status" = "200" ]; then
        local library_count=$(extract_body "$library_response" | grep -o '"id"' | wc -l)
        log_success "$library_count itens na biblioteca"
        ((PASSED++))
    else
        log_warning "Falha ao acessar biblioteca: Status $library_status"
        ((WARNINGS++))
    fi
    
    # Teste de downloads disponíveis
    log_info "Testando downloads disponíveis..."
    local downloads_response=$(make_request "GET" "/api/downloads" "" "$auth_header")
    local downloads_status=$(extract_status "$downloads_response")
    
    if [ "$downloads_status" = "200" ]; then
        log_success "Downloads disponíveis carregados"
        ((PASSED++))
    else
        log_warning "Falha ao listar downloads: Status $downloads_status"
        ((WARNINGS++))
    fi
    
    return 0
}

# Teste 5: CMS
test_cms() {
    log_section "TESTES DE CMS"
    
    # Teste de conteúdo público
    log_info "Testando conteúdo público do CMS..."
    local content_response=$(make_request "GET" "/api/cms/content")
    local content_status=$(extract_status "$content_response")
    
    if [ "$content_status" = "200" ]; then
        log_success "Conteúdo do CMS carregado"
        ((PASSED++))
    else
        log_warning "Falha ao acessar conteúdo do CMS: Status $content_status"
        ((WARNINGS++))
    fi
    
    # Teste de artigos
    log_info "Testando artigos..."
    local articles_response=$(make_request "GET" "/api/articles")
    local articles_status=$(extract_status "$articles_response")
    
    if [ "$articles_status" = "200" ]; then
        local articles_count=$(extract_body "$articles_response" | grep -o '"id"' | wc -l)
        log_success "$articles_count artigos encontrados"
        ((PASSED++))
    else
        log_warning "Falha ao carregar artigos: Status $articles_status"
        ((WARNINGS++))
    fi
    
    return 0
}

# Teste 6: Performance
test_performance() {
    log_section "TESTES DE PERFORMANCE"
    
    local endpoints=(
        "/api/articles"
        "/api/marketplace/products"
        "/api/hero/config"
        "/api/cms/content"
    )
    
    for endpoint in "${endpoints[@]}"; do
        log_info "Testando performance de $endpoint..."
        
        local start_time=$(date +%s%3N)
        local response=$(make_request "GET" "$endpoint")
        local end_time=$(date +%s%3N)
        local response_time=$((end_time - start_time))
        local status=$(extract_status "$response")
        
        if [ "$status" = "200" ]; then
            if [ "$response_time" -lt 100 ]; then
                log_success "$endpoint: ${response_time}ms (Excelente)"
                ((PASSED++))
            elif [ "$response_time" -lt 500 ]; then
                log_success "$endpoint: ${response_time}ms (Bom)"
                ((PASSED++))
            else
                log_warning "$endpoint: ${response_time}ms (Lento)"
                ((WARNINGS++))
            fi
        else
            log_error "$endpoint: Falhou (Status $status)"
            ((FAILED++))
        fi
    done
}

# Função principal
main() {
    echo -e "${CYAN}🚀 INICIANDO TESTES COMPLETOS DO SISTEMA${NC}"
    echo -e "${BLUE}Testando API em: $API_BASE${NC}"
    echo ""
    
    # Verificar se o servidor está rodando
    log_info "Verificando se o servidor está rodando..."
    local health_check=$(make_request "GET" "/api/articles")
    local health_status=$(extract_status "$health_check")
    
    if [ "$health_status" != "200" ]; then
        log_error "Servidor não está respondendo. Certifique-se de que está rodando em $API_BASE"
        exit 1
    fi
    log_success "Servidor está rodando"
    
    # Executar todos os testes
    test_authentication
    test_password_recovery
    test_marketplace
    test_downloads
    test_cms
    test_performance
    
    # Relatório final
    log_section "RELATÓRIO FINAL"
    log_success "Testes passaram: $PASSED"
    
    if [ "$FAILED" -gt 0 ]; then
        log_error "Testes falharam: $FAILED"
    fi
    
    if [ "$WARNINGS" -gt 0 ]; then
        log_warning "Avisos: $WARNINGS"
    fi
    
    local total_tests=$((PASSED + FAILED))
    if [ "$total_tests" -gt 0 ]; then
        local success_rate=$((PASSED * 100 / total_tests))
        
        echo ""
        if [ "$success_rate" -ge 80 ]; then
            log_success "Taxa de Sucesso: $success_rate% - Sistema funcionando corretamente! 🎉"
        elif [ "$success_rate" -ge 60 ]; then
            log_warning "Taxa de Sucesso: $success_rate% - Sistema funcionando com algumas limitações ⚠️"
        else
            log_error "Taxa de Sucesso: $success_rate% - Sistema com problemas significativos ❌"
        fi
    fi
    
    echo ""
    log_info "Teste completo finalizado!"
}

# Verificar dependências
if ! command -v curl &> /dev/null; then
    log_error "curl é necessário para executar este script"
    exit 1
fi

# Executar testes
main "$@"