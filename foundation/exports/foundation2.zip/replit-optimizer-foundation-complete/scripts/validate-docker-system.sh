#!/bin/bash

# Script de Validação do Sistema Docker - Replit Cost Optimizer
# Data: 28/01/2025
# Versão: 1.0

set -e

echo "🐳 Iniciando validação completa do sistema Docker..."
echo "Data: $(date)"
echo "================================================"

# Função para log colorido
log_success() { echo -e "\033[32m✅ $1\033[0m"; }
log_error() { echo -e "\033[31m❌ $1\033[0m"; }
log_info() { echo -e "\033[34mℹ️  $1\033[0m"; }
log_warning() { echo -e "\033[33m⚠️  $1\033[0m"; }

# Verificar Docker
log_info "Verificando Docker..."
if ! command -v docker &> /dev/null; then
    log_error "Docker não encontrado"
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    log_error "Docker Compose não encontrado"
    exit 1
fi

log_success "Docker $(docker --version | cut -d' ' -f3 | cut -d',' -f1) encontrado"
log_success "Docker Compose $(docker-compose --version | cut -d' ' -f3 | cut -d',' -f1) encontrado"

# Validar arquivo docker-compose.yml
log_info "Validando configuração Docker Compose..."
if docker-compose config &> /dev/null; then
    log_success "Configuração Docker Compose válida"
else
    log_error "Erro na configuração Docker Compose"
    docker-compose config
    exit 1
fi

# Verificar portas disponíveis
log_info "Verificando portas necessárias..."
PORTS=(3000 3001 3002 3003 3004 3005 3006 5432 6379 8080 9090)

for port in "${PORTS[@]}"; do
    if netstat -ln 2>/dev/null | grep ":$port " &> /dev/null; then
        log_warning "Porta $port já está em uso"
    else
        log_success "Porta $port disponível"
    fi
done

# Criar diretórios necessários
log_info "Criando estrutura de diretórios..."
mkdir -p {data/metrics,logs,temp,backups,cache,models,data/training}
mkdir -p {monitoring,nginx,scripts}

log_success "Diretórios criados"

# Validar serviços essenciais
log_info "Iniciando serviços essenciais para teste..."

# Iniciar apenas serviços base
docker-compose up -d redis postgres

sleep 10

# Testar Redis
log_info "Testando Redis..."
if docker-compose exec -T redis redis-cli ping | grep PONG &> /dev/null; then
    log_success "Redis funcionando"
else
    log_error "Redis não está respondendo"
    exit 1
fi

# Testar PostgreSQL
log_info "Testando PostgreSQL..."
if docker-compose exec -T postgres pg_isready -U postgres | grep "accepting connections" &> /dev/null; then
    log_success "PostgreSQL funcionando"
else
    log_error "PostgreSQL não está respondendo"
    exit 1
fi

# Parar serviços de teste
docker-compose down

log_info "Teste de serviços essenciais concluído"

# Gerar relatório de validação
REPORT_FILE="validation-report-$(date +%Y%m%d-%H%M%S).json"

cat > "$REPORT_FILE" << EOF
{
  "validation_timestamp": "$(date -Iseconds)",
  "docker_version": "$(docker --version)",
  "docker_compose_version": "$(docker-compose --version)",
  "system_info": {
    "os": "$(uname -s)",
    "architecture": "$(uname -m)",
    "kernel": "$(uname -r)"
  },
  "ports_checked": [$(IFS=,; echo "${PORTS[*]}")],
  "services_validated": [
    "redis",
    "postgres"
  ],
  "status": "ready_for_deployment",
  "recommendations": [
    "Execute docker-compose up -d para iniciar todos os serviços",
    "Monitore logs com docker-compose logs -f",
    "Acesse Grafana em localhost:3007 após deploy completo"
  ]
}
EOF

log_success "Relatório de validação salvo em $REPORT_FILE"

echo ""
echo "================================================"
log_success "Validação Docker concluída com sucesso!"
echo "Sistema pronto para deploy completo"
echo "================================================"