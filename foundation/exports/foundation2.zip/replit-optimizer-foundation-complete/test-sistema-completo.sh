#!/bin/bash

# =============================================================================
# SISTEMA DE TESTES COMPLETO - MARKETPLACE DIGITAL
# =============================================================================
# Script automatizado para validação completa de todas as funcionalidades
# Uso: ./test-sistema-completo.sh
# =============================================================================

set -e

API_BASE="http://localhost:5000"
LOG_FILE="test-results-$(date +%Y%m%d-%H%M%S).log"

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
PURPLE='\033[0;35m'
NC='\033[0m'

# Contadores globais
TOTAL_TESTS=0
PASSED_TESTS=0
FAILED_TESTS=0
WARNING_TESTS=0

# Configuração de teste
TEST_EMAIL="teste.sistema@marketplace.com"
TEST_PASSWORD="senhaSegura123"
NEW_PASSWORD="novaSenhaSegura456"

# Variáveis globais
AUTH_TOKEN=""
RESET_TOKEN=""
USER_ID=""

# =============================================================================
# FUNÇÕES UTILITÁRIAS
# =============================================================================

log_header() {
    echo -e "\n${CYAN}===============================================${NC}"
    echo -e "${CYAN} $1${NC}"
    echo -e "${CYAN}===============================================${NC}"
}

log_section() {
    echo -e "\n${PURPLE}🔍 $1${NC}"
    echo "$(date '+%Y-%m-%d %H:%M:%S') - SEÇÃO: $1" >> "$LOG_FILE"
}

log_test() {
    echo -e "${BLUE}   ⚡ Testando: $1${NC}"
    echo "$(date '+%Y-%m-%d %H:%M:%S') - TESTE: $1" >> "$LOG_FILE"
}

log_success() {
    echo -e "${GREEN}   ✅ $1${NC}"
    echo "$(date '+%Y-%m-%d %H:%M:%S') - SUCESSO: $1" >> "$LOG_FILE"
    ((PASSED_TESTS++))
}

log_error() {
    echo -e "${RED}   ❌ $1${NC}"
    echo "$(date '+%Y-%m-%d %H:%M:%S') - ERRO: $1" >> "$LOG_FILE"
    ((FAILED_TESTS++))
}

log_warning() {
    echo -e "${YELLOW}   ⚠️  $1${NC}"
    echo "$(date '+%Y-%m-%d %H:%M:%S') - AVISO: $1" >> "$LOG_FILE"
    ((WARNING_TESTS++))
}

# Função para fazer requisições HTTP
make_request() {
    local method=$1
    local endpoint=$2
    local data=$3
    local headers=$4
    
    ((TOTAL_TESTS++))
    
    if [ "$method" = "GET" ]; then
        if [ -n "$headers" ]; then
            curl -s -w "HTTPSTATUS:%{http_code}|TIME:%{time_total}" -H "$headers" "$API_BASE$endpoint"
        else
            curl -s -w "HTTPSTATUS:%{http_code}|TIME:%{time_total}" "$API_BASE$endpoint"
        fi
    else
        if [ -n "$headers" ]; then
            curl -s -w "HTTPSTATUS:%{http_code}|TIME:%{time_total}" -X "$method" \
                -H "Content-Type: application/json" -H "$headers" -d "$data" "$API_BASE$endpoint"
        else
            curl -s -w "HTTPSTATUS:%{http_code}|TIME:%{time_total}" -X "$method" \
                -H "Content-Type: application/json" -d "$data" "$API_BASE$endpoint"
        fi
    fi
}

# Extrair informações da resposta
extract_status() {
    echo "$1" | grep -o "HTTPSTATUS:[0-9]*" | cut -d: -f2
}

extract_time() {
    echo "$1" | grep -o "TIME:[0-9.]*" | cut -d: -f2
}

extract_body() {
    echo "$1" | sed 's/HTTPSTATUS:[0-9]*|TIME:[0-9.]*$//'
}

extract_token() {
    echo "$1" | grep -o '"token":"[^"]*"' | cut -d'"' -f4
}

extract_reset_token() {
    echo "$1" | grep -o '"resetToken":"[^"]*"' | cut -d'"' -f4
}

# =============================================================================
# TESTES DE INFRAESTRUTURA
# =============================================================================

test_infrastructure() {
    log_section "Infraestrutura e Conectividade"
    
    log_test "Verificando se servidor está rodando"
    local health_response=$(make_request "GET" "/api/articles")
    local health_status=$(extract_status "$health_response")
    local health_time=$(extract_time "$health_response")
    
    if [ "$health_status" = "200" ]; then
        log_success "Servidor respondendo em ${health_time}s"
    else
        log_error "Servidor não está respondendo (Status: $health_status)"
        exit 1
    fi
    
    log_test "Verificando APIs principais"
    local endpoints=(
        "/api/articles"
        "/api/marketplace/products"
        "/api/hero/config"
        "/api/cms/content"
    )
    
    for endpoint in "${endpoints[@]}"; do
        local response=$(make_request "GET" "$endpoint")
        local status=$(extract_status "$response")
        local time=$(extract_time "$response")
        
        if [ "$status" = "200" ]; then
            if (( $(echo "$time < 0.1" | bc -l) )); then
                log_success "$endpoint: ${time}s (Excelente)"
            elif (( $(echo "$time < 0.5" | bc -l) )); then
                log_success "$endpoint: ${time}s (Bom)"
            else
                log_warning "$endpoint: ${time}s (Lento)"
            fi
        else
            log_error "$endpoint falhou (Status: $status)"
        fi
    done
}

# =============================================================================
# TESTES DE AUTENTICAÇÃO
# =============================================================================

test_authentication() {
    log_section "Sistema de Autenticação"
    
    # Teste de registro
    log_test "Registro de novo usuário"
    local register_data="{\"email\":\"$TEST_EMAIL\",\"password\":\"$TEST_PASSWORD\",\"name\":\"Usuário Teste\",\"userType\":\"customer\"}"
    local register_response=$(make_request "POST" "/api/auth/register" "$register_data")
    local register_status=$(extract_status "$register_response")
    
    if [ "$register_status" = "200" ] || [ "$register_status" = "201" ]; then
        log_success "Usuário registrado com sucesso"
        AUTH_TOKEN=$(extract_token "$register_response")
        USER_ID=$(extract_body "$register_response" | grep -o '"id":[0-9]*' | cut -d: -f2)
    else
        log_warning "Registro falhou - usuário pode já existir (Status: $register_status)"
    fi
    
    # Teste de login
    log_test "Login do usuário"
    local login_data="{\"email\":\"$TEST_EMAIL\",\"password\":\"$TEST_PASSWORD\"}"
    local login_response=$(make_request "POST" "/api/auth/login" "$login_data")
    local login_status=$(extract_status "$login_response")
    
    if [ "$login_status" = "200" ]; then
        log_success "Login realizado com sucesso"
        AUTH_TOKEN=$(extract_token "$login_response")
        if [ -z "$USER_ID" ]; then
            USER_ID=$(extract_body "$login_response" | grep -o '"id":[0-9]*' | cut -d: -f2)
        fi
    else
        log_error "Login falhou (Status: $login_status)"
        return 1
    fi
    
    # Teste de validação de token
    if [ -n "$AUTH_TOKEN" ]; then
        log_test "Validação de token JWT"
        local auth_header="Authorization: Bearer $AUTH_TOKEN"
        local validate_response=$(make_request "GET" "/api/dashboard/stats" "" "$auth_header")
        local validate_status=$(extract_status "$validate_response")
        
        if [ "$validate_status" = "200" ]; then
            log_success "Token JWT válido e funcional"
        else
            log_warning "Token pode ter problemas (Status: $validate_status)"
        fi
    fi
}

# =============================================================================
# TESTES DE RECUPERAÇÃO DE SENHA
# =============================================================================

test_password_recovery() {
    log_section "Sistema de Recuperação de Senha"
    
    # Teste 1: Solicitar recuperação
    log_test "Solicitação de recuperação de senha"
    local forgot_data="{\"email\":\"$TEST_EMAIL\"}"
    local forgot_response=$(make_request "POST" "/api/auth/forgot-password" "$forgot_data")
    local forgot_status=$(extract_status "$forgot_response")
    
    if [ "$forgot_status" = "200" ]; then
        log_success "Solicitação de recuperação processada"
        RESET_TOKEN=$(extract_reset_token "$forgot_response")
        
        if [ -n "$RESET_TOKEN" ]; then
            log_success "Token de reset gerado: ${RESET_TOKEN:0:20}..."
        else
            log_warning "Token não encontrado na resposta"
        fi
    else
        log_error "Falha na solicitação de recuperação (Status: $forgot_status)"
        return 1
    fi
    
    # Teste 2: Verificação de token
    if [ -n "$RESET_TOKEN" ]; then
        log_test "Verificação de token de reset"
        local verify_response=$(make_request "GET" "/api/auth/verify-reset-token/$RESET_TOKEN")
        local verify_status=$(extract_status "$verify_response")
        
        if [ "$verify_status" = "200" ]; then
            local email_from_token=$(extract_body "$verify_response" | grep -o '"email":"[^"]*"' | cut -d'"' -f4)
            if [ "$email_from_token" = "$TEST_EMAIL" ]; then
                log_success "Token válido para email correto"
            else
                log_warning "Token válido mas email não confere"
            fi
        else
            log_error "Token de reset inválido (Status: $verify_status)"
            return 1
        fi
    fi
    
    # Teste 3: Reset de senha
    if [ -n "$RESET_TOKEN" ]; then
        log_test "Redefinição de senha"
        local reset_data="{\"token\":\"$RESET_TOKEN\",\"newPassword\":\"$NEW_PASSWORD\"}"
        local reset_response=$(make_request "POST" "/api/auth/reset-password" "$reset_data")
        local reset_status=$(extract_status "$reset_response")
        
        if [ "$reset_status" = "200" ]; then
            log_success "Senha redefinida com sucesso"
            
            # Teste 4: Login com nova senha
            log_test "Login com nova senha"
            local new_login_data="{\"email\":\"$TEST_EMAIL\",\"password\":\"$NEW_PASSWORD\"}"
            local new_login_response=$(make_request "POST" "/api/auth/login" "$new_login_data")
            local new_login_status=$(extract_status "$new_login_response")
            
            if [ "$new_login_status" = "200" ]; then
                log_success "Login com nova senha funcionou"
                AUTH_TOKEN=$(extract_token "$new_login_response")
            else
                log_warning "Login com nova senha falhou (Status: $new_login_status)"
            fi
            
            # Restaurar senha original para próximos testes
            log_test "Restaurando senha original"
            local restore_forgot=$(make_request "POST" "/api/auth/forgot-password" "$forgot_data")
            local new_reset_token=$(extract_reset_token "$restore_forgot")
            if [ -n "$new_reset_token" ]; then
                local restore_data="{\"token\":\"$new_reset_token\",\"newPassword\":\"$TEST_PASSWORD\"}"
                make_request "POST" "/api/auth/reset-password" "$restore_data" > /dev/null
                log_success "Senha original restaurada"
            fi
        else
            log_error "Falha na redefinição de senha (Status: $reset_status)"
        fi
    fi
}

# =============================================================================
# TESTES DE MARKETPLACE
# =============================================================================

test_marketplace() {
    log_section "Sistema de Marketplace"
    
    # Teste de produtos
    log_test "Listagem de produtos"
    local products_response=$(make_request "GET" "/api/marketplace/products")
    local products_status=$(extract_status "$products_response")
    
    if [ "$products_status" = "200" ]; then
        local product_count=$(extract_body "$products_response" | grep -o '"id"' | wc -l)
        log_success "$product_count produtos disponíveis"
        
        # Verificar se há produtos premium
        local premium_count=$(extract_body "$products_response" | grep -c '"isPremium":true' || echo "0")
        log_success "$premium_count produtos premium encontrados"
    else
        log_error "Falha ao listar produtos (Status: $products_status)"
    fi
    
    # Teste de categorias
    log_test "Listagem de categorias"
    local categories_response=$(make_request "GET" "/api/marketplace/categories")
    local categories_status=$(extract_status "$categories_response")
    
    if [ "$categories_status" = "200" ]; then
        log_success "Categorias carregadas com sucesso"
    else
        log_warning "Falha ao carregar categorias (Status: $categories_status)"
    fi
    
    # Teste de filtros
    log_test "Filtro de produtos premium"
    local premium_response=$(make_request "GET" "/api/marketplace/products?premium=true")
    local premium_status=$(extract_status "$premium_response")
    
    if [ "$premium_status" = "200" ]; then
        log_success "Filtro premium funcionando"
    else
        log_warning "Falha no filtro premium (Status: $premium_status)"
    fi
}

# =============================================================================
# TESTES DE DOWNLOADS E BIBLIOTECA
# =============================================================================

test_downloads() {
    log_section "Sistema de Downloads"
    
    if [ -z "$AUTH_TOKEN" ]; then
        log_error "Token de autenticação necessário para testes de downloads"
        return 1
    fi
    
    local auth_header="Authorization: Bearer $AUTH_TOKEN"
    
    # Teste de biblioteca do usuário
    log_test "Biblioteca pessoal do usuário"
    local library_response=$(make_request "GET" "/api/downloads/my-library" "" "$auth_header")
    local library_status=$(extract_status "$library_response")
    
    if [ "$library_status" = "200" ]; then
        local library_count=$(extract_body "$library_response" | grep -o '"id"' | wc -l)
        log_success "$library_count itens na biblioteca pessoal"
    else
        log_warning "Falha ao acessar biblioteca (Status: $library_status)"
    fi
    
    # Teste de downloads disponíveis
    log_test "Downloads disponíveis"
    local downloads_response=$(make_request "GET" "/api/downloads" "" "$auth_header")
    local downloads_status=$(extract_status "$downloads_response")
    
    if [ "$downloads_status" = "200" ]; then
        log_success "Lista de downloads carregada"
    else
        log_warning "Falha ao carregar downloads (Status: $downloads_status)"
    fi
    
    # Teste de estatísticas
    log_test "Estatísticas do usuário"
    local stats_response=$(make_request "GET" "/api/dashboard/stats" "" "$auth_header")
    local stats_status=$(extract_status "$stats_response")
    
    if [ "$stats_status" = "200" ]; then
        log_success "Estatísticas carregadas com sucesso"
    else
        log_warning "Falha ao carregar estatísticas (Status: $stats_status)"
    fi
}

# =============================================================================
# TESTES DE FAVORITOS
# =============================================================================

test_favorites() {
    log_section "Sistema de Favoritos"
    
    if [ -z "$AUTH_TOKEN" ]; then
        log_error "Token necessário para testes de favoritos"
        return 1
    fi
    
    local auth_header="Authorization: Bearer $AUTH_TOKEN"
    
    # Teste de listagem de favoritos
    log_test "Listagem de favoritos"
    local favorites_response=$(make_request "GET" "/api/favorites" "" "$auth_header")
    local favorites_status=$(extract_status "$favorites_response")
    
    if [ "$favorites_status" = "200" ]; then
        local favorites_count=$(extract_body "$favorites_response" | grep -o '"id"' | wc -l)
        log_success "$favorites_count itens favoritados"
    else
        log_warning "Falha ao listar favoritos (Status: $favorites_status)"
    fi
    
    # Teste de adicionar/remover favorito
    local products_response=$(make_request "GET" "/api/marketplace/products")
    if [ "$(extract_status "$products_response")" = "200" ]; then
        local first_product_id=$(extract_body "$products_response" | grep -o '"id":[0-9]*' | head -1 | cut -d: -f2)
        
        if [ -n "$first_product_id" ]; then
            log_test "Adicionando produto aos favoritos"
            local add_favorite_response=$(make_request "POST" "/api/favorites/$first_product_id" "" "$auth_header")
            local add_favorite_status=$(extract_status "$add_favorite_response")
            
            if [ "$add_favorite_status" = "200" ] || [ "$add_favorite_status" = "201" ]; then
                log_success "Produto adicionado aos favoritos"
                
                log_test "Removendo produto dos favoritos"
                local remove_favorite_response=$(make_request "DELETE" "/api/favorites/$first_product_id" "" "$auth_header")
                local remove_favorite_status=$(extract_status "$remove_favorite_response")
                
                if [ "$remove_favorite_status" = "200" ]; then
                    log_success "Produto removido dos favoritos"
                else
                    log_warning "Falha ao remover favorito (Status: $remove_favorite_status)"
                fi
            else
                log_warning "Falha ao adicionar favorito (Status: $add_favorite_status)"
            fi
        fi
    fi
}

# =============================================================================
# TESTES DE CMS
# =============================================================================

test_cms() {
    log_section "Sistema de CMS"
    
    # Teste de conteúdo público
    log_test "Conteúdo público do CMS"
    local cms_response=$(make_request "GET" "/api/cms/content")
    local cms_status=$(extract_status "$cms_response")
    
    if [ "$cms_status" = "200" ]; then
        local content_count=$(extract_body "$cms_response" | grep -o '"id"' | wc -l)
        log_success "$content_count itens de conteúdo disponíveis"
    else
        log_warning "Falha ao carregar conteúdo CMS (Status: $cms_status)"
    fi
    
    # Teste de artigos
    log_test "Sistema de artigos"
    local articles_response=$(make_request "GET" "/api/articles")
    local articles_status=$(extract_status "$articles_response")
    
    if [ "$articles_status" = "200" ]; then
        local articles_count=$(extract_body "$articles_response" | grep -o '"id"' | wc -l)
        log_success "$articles_count artigos publicados"
    else
        log_warning "Falha ao carregar artigos (Status: $articles_status)"
    fi
    
    # Teste de configurações
    local configs=(
        "/api/hero/config:Hero Section"
        "/api/sobre/config:Sobre"
        "/api/contato/config:Contato"
        "/api/como-funciona/config:Como Funciona"
    )
    
    for config in "${configs[@]}"; do
        local endpoint=$(echo "$config" | cut -d: -f1)
        local name=$(echo "$config" | cut -d: -f2)
        
        log_test "Configuração: $name"
        local config_response=$(make_request "GET" "$endpoint")
        local config_status=$(extract_status "$config_response")
        
        if [ "$config_status" = "200" ]; then
            log_success "Configuração $name carregada"
        else
            log_warning "Falha na configuração $name (Status: $config_status)"
        fi
    done
}

# =============================================================================
# TESTES DE PERFORMANCE E CARGA
# =============================================================================

test_performance() {
    log_section "Performance e Carga"
    
    local performance_endpoints=(
        "/api/articles:Artigos"
        "/api/marketplace/products:Produtos"
        "/api/hero/config:Hero Config"
        "/api/cms/content:CMS Content"
    )
    
    log_test "Benchmark de APIs principais"
    for endpoint_info in "${performance_endpoints[@]}"; do
        local endpoint=$(echo "$endpoint_info" | cut -d: -f1)
        local name=$(echo "$endpoint_info" | cut -d: -f2)
        
        local total_time=0
        local successful_requests=0
        local failed_requests=0
        
        # Fazer 5 requisições para média
        for i in {1..5}; do
            local response=$(make_request "GET" "$endpoint")
            local status=$(extract_status "$response")
            local time=$(extract_time "$response")
            
            if [ "$status" = "200" ]; then
                total_time=$(echo "$total_time + $time" | bc -l)
                ((successful_requests++))
            else
                ((failed_requests++))
            fi
        done
        
        if [ "$successful_requests" -gt 0 ]; then
            # Calcular média simples sem bc
            local avg_time_ms=$(echo "$total_time * 1000 / $successful_requests" | awk '{printf "%.0f", $1}')
            local avg_time=$(echo "$total_time / $successful_requests" | awk '{printf "%.3f", $1}')
            
            if [ "$avg_time_ms" -lt 100 ]; then
                log_success "$name: ${avg_time}s médio (Excelente)"
            elif [ "$avg_time_ms" -lt 500 ]; then
                log_success "$name: ${avg_time}s médio (Bom)"
            else
                log_warning "$name: ${avg_time}s médio (Lento)"
            fi
        else
            log_error "$name: Todas as requisições falharam"
        fi
    done
    
    # Teste de carga simultânea
    log_test "Teste de carga simultânea"
    local concurrent_pids=()
    
    for i in {1..10}; do
        (make_request "GET" "/api/articles" > /dev/null 2>&1) &
        concurrent_pids+=($!)
    done
    
    # Aguardar todas as requisições
    local concurrent_success=0
    for pid in "${concurrent_pids[@]}"; do
        if wait "$pid"; then
            ((concurrent_success++))
        fi
    done
    
    if [ "$concurrent_success" -ge 8 ]; then
        log_success "Teste de carga: $concurrent_success/10 requisições bem-sucedidas"
    else
        log_warning "Teste de carga: apenas $concurrent_success/10 requisições bem-sucedidas"
    fi
}

# =============================================================================
# RELATÓRIO FINAL
# =============================================================================

generate_final_report() {
    log_header "RELATÓRIO FINAL DE TESTES"
    
    local success_rate=0
    if [ "$TOTAL_TESTS" -gt 0 ]; then
        success_rate=$(echo "$PASSED_TESTS * 100 / $TOTAL_TESTS" | awk '{printf "%.1f", $1}')
    fi
    
    echo -e "${GREEN}✅ Testes Passaram: $PASSED_TESTS${NC}"
    echo -e "${RED}❌ Testes Falharam: $FAILED_TESTS${NC}"
    echo -e "${YELLOW}⚠️  Avisos: $WARNING_TESTS${NC}"
    echo -e "${BLUE}📊 Total de Testes: $TOTAL_TESTS${NC}"
    echo -e "${PURPLE}📈 Taxa de Sucesso: $success_rate%${NC}"
    
    echo -e "\n${CYAN}📋 RESUMO EXECUTIVO:${NC}"
    
    local rate_int=$(echo "$success_rate" | cut -d. -f1)
    if [ "$rate_int" -ge 90 ]; then
        echo -e "${GREEN}🎉 Sistema EXCELENTE - Pronto para produção!${NC}"
    elif [ "$rate_int" -ge 80 ]; then
        echo -e "${GREEN}✅ Sistema BOM - Funcional com pequenos ajustes${NC}"
    elif [ "$rate_int" -ge 70 ]; then
        echo -e "${YELLOW}⚠️  Sistema REGULAR - Necessita melhorias${NC}"
    else
        echo -e "${RED}❌ Sistema COM PROBLEMAS - Requer atenção urgente${NC}"
    fi
    
    echo -e "\n${CYAN}📁 Log detalhado salvo em: $LOG_FILE${NC}"
    echo -e "${CYAN}📅 Teste executado em: $(date '+%d/%m/%Y às %H:%M:%S')${NC}"
    
    # Salvar resumo no log
    echo "" >> "$LOG_FILE"
    echo "=================== RESUMO FINAL ===================" >> "$LOG_FILE"
    echo "Testes Passaram: $PASSED_TESTS" >> "$LOG_FILE"
    echo "Testes Falharam: $FAILED_TESTS" >> "$LOG_FILE"
    echo "Avisos: $WARNING_TESTS" >> "$LOG_FILE"
    echo "Total: $TOTAL_TESTS" >> "$LOG_FILE"
    echo "Taxa de Sucesso: $success_rate%" >> "$LOG_FILE"
    echo "====================================================" >> "$LOG_FILE"
}

# =============================================================================
# FUNÇÃO PRINCIPAL
# =============================================================================

main() {
    clear
    log_header "SISTEMA DE TESTES COMPLETO - MARKETPLACE DIGITAL"
    
    echo -e "${BLUE}🚀 Iniciando bateria completa de testes...${NC}"
    echo -e "${BLUE}📍 API Base: $API_BASE${NC}"
    echo -e "${BLUE}📝 Log File: $LOG_FILE${NC}"
    echo ""
    
    # Inicializar log
    echo "SISTEMA DE TESTES COMPLETO - $(date)" > "$LOG_FILE"
    echo "API Base: $API_BASE" >> "$LOG_FILE"
    echo "========================================" >> "$LOG_FILE"
    
    # Verificar dependências
    if ! command -v curl &> /dev/null; then
        log_error "curl é necessário para executar os testes"
        exit 1
    fi
    
    # Executar todos os testes
    test_infrastructure
    test_authentication
    test_password_recovery
    test_marketplace
    test_downloads
    test_favorites
    test_cms
    test_performance
    
    # Gerar relatório final
    generate_final_report
    
    echo -e "\n${CYAN}🏁 Testes concluídos com sucesso!${NC}"
    echo -e "${CYAN}💡 Execute este script sempre que quiser validar o sistema${NC}"
}

# Verificar se o script está sendo executado diretamente
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    main "$@"
fi